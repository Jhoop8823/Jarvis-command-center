import { relations } from "drizzle-orm";
import { users, localUsers, conversations, messages, systemPrompts, apiKeys } from "./schema";

export const usersRelations = relations(users, ({ many }) => ({
  conversations: many(conversations),
}));

export const localUsersRelations = relations(localUsers, ({ many }) => ({
  conversations: many(conversations),
}));

export const conversationsRelations = relations(conversations, ({ many, one }) => ({
  messages: many(messages),
  systemPrompt: one(systemPrompts, {
    fields: [conversations.systemPromptId],
    references: [systemPrompts.id],
  }),
}));

export const messagesRelations = relations(messages, ({ one }) => ({
  conversation: one(conversations, {
    fields: [messages.conversationId],
    references: [conversations.id],
  }),
}));

export const systemPromptsRelations = relations(systemPrompts, ({ many }) => ({
  conversations: many(conversations),
}));

export const apiKeysRelations = relations(apiKeys, ({}) => ({}));
