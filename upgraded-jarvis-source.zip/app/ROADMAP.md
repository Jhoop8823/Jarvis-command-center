# J.A.R.V.I.S Product Roadmap

## North Star

Build a personal AI operations center that feels like a command cockpit, not a generic chatbot.

## Must-Win Features

1. **Flawless chat core**
   - fast response flow
   - clean streaming/loading state
   - conversation persistence
   - provider/model selection

2. **Prompt command system**
   - reusable system prompts
   - fast prompt switching
   - role/mode presets

3. **Secure provider control**
   - OpenAI, Anthropic, and Google support
   - server-side key handling
   - provider health checks

4. **Operational dashboard**
   - recent conversations
   - active provider status
   - command shortcuts
   - system health indicators

5. **Automation layer**
   - scheduled tasks
   - external API actions
   - user-created workflows

## Do Not Do Yet

Avoid adding too many half-finished modules. The strongest move is to make the core 3–5 systems reliable and polished before expanding.
