# J.A.R.V.I.S Command Center

A modern AI operations dashboard built as a multi-provider command center for chat, system prompts, conversation management, admin controls, and secure API-key configuration.

This project is no longer just a generic Vite starter. It is structured like a real AI platform: React frontend, Hono/tRPC backend, Drizzle ORM database layer, authentication, and provider-specific AI integrations.

## Core Identity

**J.A.R.V.I.S Command Center** is a personal AI operations center.

Its strongest direction is not “another chatbot.” Its winning lane is a controlled cockpit for:

- multi-model AI access
- reusable system prompts
- organized conversation history
- admin visibility
- secure provider credentials
- future automation modules

## Current Feature Set

- **Authentication flow** with protected routes
- **Chat interface** for AI interaction
- **Conversation history** and message storage
- **System prompt management**
- **API key management** for OpenAI, Anthropic, and Google Gemini
- **Admin dashboard**
- **Responsive cyber/HUD-style UI**
- **Database schema and migrations via Drizzle**
- **tRPC API layer** for typed frontend/backend communication

## Tech Stack

| Layer | Technology |
|---|---|
| Frontend | React 19, TypeScript, Vite |
| UI | Tailwind CSS, shadcn-style components, Framer Motion |
| API | Hono, tRPC |
| Database | MySQL, Drizzle ORM |
| Auth | Kimi auth + local auth utilities |
| AI Providers | OpenAI, Anthropic, Google Gemini |
| Tooling | ESLint, Prettier, Vitest |

## Security Notes

API keys are sensitive credentials. This build includes a safer API-key handling pattern:

- keys are encrypted before database storage
- saved key values are not returned to the browser after storage
- the frontend only shows whether each provider is configured
- keys are decrypted server-side only when testing or making provider calls
- production requires a real `APP_SECRET`

Do not deploy this with a weak or shared `APP_SECRET`.

## Environment Setup

Create a `.env` file using `.env.example` as the template.

Required production variables:

```bash
APP_ID=
APP_SECRET=
DATABASE_URL=
KIMI_AUTH_URL=
KIMI_OPEN_URL=
OWNER_UNION_ID=
VITE_KIMI_AUTH_URL=
VITE_APP_ID=
```

## Install

```bash
npm install
```

## Development

```bash
npm run dev
```

## Type Check

```bash
npm run check
```

## Build

```bash
npm run build
```

## Database

Generate migrations:

```bash
npm run db:generate
```

Run migrations:

```bash
npm run db:migrate
```

Push schema directly:

```bash
npm run db:push
```

## Product Roadmap

### Phase 1 — Stabilize the Core

- polish chat UX
- improve loading and error states
- add empty states across every page
- strengthen mobile layout
- add provider-level failure messages

### Phase 2 — Make It Feel Like J.A.R.V.I.S

- command palette
- voice input/output
- dashboard widgets
- persistent memory controls
- mission/task mode
- activity log

### Phase 3 — Turn It Into an Automation Cockpit

- scheduled prompts
- webhook actions
- file/document analysis
- browser/search tools
- external API integrations
- user-created workflows

### Phase 4 — Production Hardening

- audit auth and authorization
- add rate limiting
- add request logging
- add encrypted secret rotation strategy
- add integration tests
- add deployment documentation

## Positioning Statement

J.A.R.V.I.S Command Center is a modular AI cockpit for controlling conversations, models, prompts, credentials, and future automations from one focused interface.
