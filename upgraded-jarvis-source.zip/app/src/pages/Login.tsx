import { useState } from "react";
import { motion } from "framer-motion";
import { Eye, EyeOff, LogIn, UserPlus, Shield } from "lucide-react";
import { trpc } from "@/providers/trpc";
import ParallaxBackground from "@/components/ParallaxBackground";

function getOAuthUrl() {
  const kimiAuthUrl = import.meta.env.VITE_KIMI_AUTH_URL;
  const appID = import.meta.env.VITE_APP_ID;
  const redirectUri = `${window.location.origin}/api/oauth/callback`;
  const state = btoa(redirectUri);

  const url = new URL(`${kimiAuthUrl}/api/oauth/authorize`);
  url.searchParams.set("client_id", appID);
  url.searchParams.set("redirect_uri", redirectUri);
  url.searchParams.set("response_type", "code");
  url.searchParams.set("scope", "profile");
  url.searchParams.set("state", state);

  return url.toString();
}

export default function Login() {
  const [mode, setMode] = useState<"login" | "register">("login");
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [displayName, setDisplayName] = useState("");
  const [email, setEmail] = useState("");
  const [showPassword, setShowPassword] = useState(false);
  const [error, setError] = useState("");

  const registerMutation = trpc.localAuth.register.useMutation({
    onSuccess: (data) => {
      localStorage.setItem("local_auth_token", data.token);
      window.location.href = "/";
    },
    onError: (err) => setError(err.message),
  });

  const loginMutation = trpc.localAuth.login.useMutation({
    onSuccess: (data) => {
      localStorage.setItem("local_auth_token", data.token);
      window.location.href = "/";
    },
    onError: (err) => setError(err.message),
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setError("");

    if (mode === "register") {
      registerMutation.mutate({
        username,
        password,
        displayName: displayName || undefined,
        email: email || undefined,
      });
    } else {
      loginMutation.mutate({ username, password });
    }
  };

  const isLoading = registerMutation.isPending || loginMutation.isPending;

  return (
    <div className="h-screen w-full bg-[#0a0f1a] overflow-hidden relative flex items-center justify-center">
      <ParallaxBackground />
      <div className="scan-line opacity-20" />

      <motion.div
        initial={{ opacity: 0, y: 20, scale: 0.98 }}
        animate={{ opacity: 1, y: 0, scale: 1 }}
        transition={{ duration: 0.6, ease: "easeOut" }}
        className="relative z-10 w-full max-w-md mx-4"
      >
        {/* Glass Panel */}
        <div className="glass-panel rounded-2xl p-8 overflow-hidden">
          {/* Ambient glow behind */}
          <div className="absolute -top-20 -right-20 w-40 h-40 bg-cyan-500/10 rounded-full blur-[80px]" />
          <div className="absolute -bottom-20 -left-20 w-40 h-40 bg-cyan-500/5 rounded-full blur-[80px]" />

          {/* Header */}
          <div className="relative text-center mb-8">
            <motion.div
              initial={{ scale: 0 }}
              animate={{ scale: 1 }}
              transition={{ delay: 0.2, type: "spring", stiffness: 200 }}
              className="w-16 h-16 mx-auto mb-4 rounded-full bg-cyan-500/10 border border-cyan-500/20 flex items-center justify-center"
            >
              <img
                src="/jarvis-avatar.png"
                alt="JARVIS"
                className="w-12 h-12 rounded-full object-cover"
              />
            </motion.div>
            <h1 className="text-xl font-semibold text-cyan-200 tracking-wider mb-1">
              J.A.R.V.I.S
            </h1>
            <p className="text-xs text-cyan-400/40 font-mono-telemetry">
              {mode === "login" ? "AUTHENTICATION REQUIRED" : "NEW USER REGISTRATION"}
            </p>
          </div>

          {/* OAuth Button */}
          <motion.button
            whileHover={{ scale: 1.01 }}
            whileTap={{ scale: 0.99 }}
            onClick={() => {
              window.location.href = getOAuthUrl();
            }}
            className="w-full glass-button-primary py-3 px-4 rounded-xl mb-6 flex items-center justify-center gap-2 text-sm font-medium"
          >
            <Shield className="w-4 h-4" />
            Sign in with Kimi
          </motion.button>

          {/* Divider */}
          <div className="flex items-center gap-3 mb-6">
            <div className="flex-1 h-px bg-cyan-500/10" />
            <span className="text-[10px] text-cyan-400/30 font-mono-telemetry">OR</span>
            <div className="flex-1 h-px bg-cyan-500/10" />
          </div>

          {/* Local Auth Form */}
          <form onSubmit={handleSubmit} className="space-y-4 relative">
            {error && (
              <motion.div
                initial={{ opacity: 0, y: -10 }}
                animate={{ opacity: 1, y: 0 }}
                className="p-3 rounded-lg bg-red-500/10 border border-red-500/20 text-red-400 text-xs"
              >
                {error}
              </motion.div>
            )}

            <div>
              <label className="telemetry-text block mb-1.5">Username</label>
              <input
                type="text"
                value={username}
                onChange={(e) => setUsername(e.target.value)}
                className="w-full glass-input px-4 py-2.5 rounded-lg text-sm"
                placeholder="Enter username"
                required
                minLength={3}
              />
            </div>

            {mode === "register" && (
              <>
                <div>
                  <label className="telemetry-text block mb-1.5">Display Name</label>
                  <input
                    type="text"
                    value={displayName}
                    onChange={(e) => setDisplayName(e.target.value)}
                    className="w-full glass-input px-4 py-2.5 rounded-lg text-sm"
                    placeholder="Your display name"
                  />
                </div>
                <div>
                  <label className="telemetry-text block mb-1.5">Email</label>
                  <input
                    type="email"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    className="w-full glass-input px-4 py-2.5 rounded-lg text-sm"
                    placeholder="Optional email"
                  />
                </div>
              </>
            )}

            <div>
              <label className="telemetry-text block mb-1.5">Password</label>
              <div className="relative">
                <input
                  type={showPassword ? "text" : "password"}
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  className="w-full glass-input px-4 py-2.5 rounded-lg text-sm pr-10"
                  placeholder="Enter password"
                  required
                  minLength={6}
                />
                <button
                  type="button"
                  onClick={() => setShowPassword(!showPassword)}
                  className="absolute right-3 top-1/2 -translate-y-1/2 text-cyan-400/30 hover:text-cyan-300/60 transition-colors"
                >
                  {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                </button>
              </div>
            </div>

            <motion.button
              whileHover={{ scale: 1.01 }}
              whileTap={{ scale: 0.99 }}
              type="submit"
              disabled={isLoading}
              className="w-full glass-button py-3 px-4 rounded-xl flex items-center justify-center gap-2 text-sm font-medium disabled:opacity-50"
            >
              {isLoading ? (
                <div className="w-4 h-4 border-2 border-cyan-400/30 border-t-cyan-400 rounded-full animate-spin" />
              ) : mode === "login" ? (
                <>
                  <LogIn className="w-4 h-4" />
                  Sign In
                </>
              ) : (
                <>
                  <UserPlus className="w-4 h-4" />
                  Create Account
                </>
              )}
            </motion.button>
          </form>

          {/* Toggle Mode */}
          <div className="mt-6 text-center">
            <button
              onClick={() => {
                setMode(mode === "login" ? "register" : "login");
                setError("");
              }}
              className="text-xs text-cyan-400/40 hover:text-cyan-300/70 transition-colors"
            >
              {mode === "login"
                ? "Need an account? Register"
                : "Already have an account? Sign In"}
            </button>
          </div>
        </div>
      </motion.div>
    </div>
  );
}
