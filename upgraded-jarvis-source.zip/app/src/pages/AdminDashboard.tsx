import { useState } from "react";
import { useNavigate } from "react-router";
import { motion } from "framer-motion";
import {
  Shield,
  Users,
  MessageSquare,
  ChevronLeft,
  ChevronRight,
  Search,
  Crown,
  User,
} from "lucide-react";
import { trpc } from "@/providers/trpc";
import { useAuth } from "@/hooks/useAuth";

export default function AdminDashboard() {
  const navigate = useNavigate();
  const { isAdmin, isLoading: authLoading } = useAuth();
  const [page, setPage] = useState(1);
  const [search, setSearch] = useState("");

  const { data: stats } = trpc.admin.getStats.useQuery(undefined, {
    enabled: isAdmin,
  });

  const { data: usersData } = trpc.admin.getUsers.useQuery(
    { page, limit: 20, search: search || undefined },
    { enabled: isAdmin },
  );

  const updateRole = trpc.admin.updateUserRole.useMutation({
    onSuccess: () => {
      utils.admin.getUsers.invalidate();
    },
  });

  const utils = trpc.useUtils();

  if (authLoading) {
    return (
      <div className="h-full flex items-center justify-center">
        <div className="w-8 h-8 border-2 border-cyan-400/20 border-t-cyan-400 rounded-full animate-spin" />
      </div>
    );
  }

  if (!isAdmin) {
    return (
      <div className="h-full flex items-center justify-center">
        <div className="text-center">
          <Shield className="w-16 h-16 text-red-400/20 mx-auto mb-4" />
          <h2 className="text-lg font-semibold text-red-300/60 mb-2">Access Denied</h2>
          <p className="text-sm text-cyan-200/30 mb-4">
            Admin privileges required to access this page.
          </p>
          <button
            onClick={() => navigate("/")}
            className="glass-button px-4 py-2 rounded-lg text-xs"
          >
            Return to Command Center
          </button>
        </div>
      </div>
    );
  }

  const totalPages = usersData ? Math.ceil(usersData.total / 20) : 1;

  return (
    <div className="h-full glass-panel rounded-xl overflow-hidden flex flex-col">
      {/* Header */}
      <div className="h-14 border-b border-cyan-500/10 flex items-center justify-between px-6">
        <div className="flex items-center gap-3">
          <Shield className="w-5 h-5 text-cyan-400/60" />
          <h1 className="text-lg font-semibold text-cyan-200">Admin Dashboard</h1>
        </div>
      </div>

      {/* Content */}
      <div className="flex-1 overflow-auto p-6">
        {/* Stats Cards */}
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
          {[
            {
              label: "Total Users",
              value: stats?.totalUsers || 0,
              icon: Users,
              color: "text-cyan-400",
            },
            {
              label: "OAuth Users",
              value: stats?.totalOAuthUsers || 0,
              icon: User,
              color: "text-emerald-400",
            },
            {
              label: "Local Users",
              value: stats?.totalLocalUsers || 0,
              icon: User,
              color: "text-amber-400",
            },
            {
              label: "Conversations",
              value: stats?.totalConversations || 0,
              icon: MessageSquare,
              color: "text-violet-400",
            },
          ].map((stat, index) => (
            <motion.div
              key={stat.label}
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: index * 0.1 }}
              className="glass-panel rounded-xl p-4"
            >
              <div className="flex items-center justify-between mb-2">
                <span className="telemetry-text">{stat.label}</span>
                <stat.icon className={`w-4 h-4 ${stat.color}/40`} />
              </div>
              <p className={`text-2xl font-bold ${stat.color}`}>{stat.value}</p>
            </motion.div>
          ))}
        </div>

        {/* Search */}
        <div className="flex items-center gap-3 mb-4">
          <div className="relative flex-1 max-w-sm">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-cyan-400/30" />
            <input
              type="text"
              value={search}
              onChange={(e) => {
                setSearch(e.target.value);
                setPage(1);
              }}
              placeholder="Search users..."
              className="w-full glass-input pl-9 pr-3 py-2 rounded-lg text-xs"
            />
          </div>
        </div>

        {/* Users Table */}
        <div className="glass-panel rounded-xl overflow-hidden">
          <table className="w-full">
            <thead>
              <tr className="border-b border-cyan-500/10">
                <th className="text-left px-4 py-3 telemetry-text">ID</th>
                <th className="text-left px-4 py-3 telemetry-text">NAME</th>
                <th className="text-left px-4 py-3 telemetry-text">EMAIL</th>
                <th className="text-left px-4 py-3 telemetry-text">TYPE</th>
                <th className="text-left px-4 py-3 telemetry-text">ROLE</th>
                <th className="text-left px-4 py-3 telemetry-text">ACTIONS</th>
              </tr>
            </thead>
            <tbody>
              {usersData?.users.map((user, index) => (
                <motion.tr
                  key={`${user.userType}-${user.id}`}
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  transition={{ delay: index * 0.03 }}
                  className="border-b border-cyan-500/5 hover:bg-cyan-500/[0.02] transition-colors"
                >
                  <td className="px-4 py-3 text-xs text-cyan-200/50">{user.id}</td>
                  <td className="px-4 py-3">
                    <div className="flex items-center gap-2">
                      <div className="w-6 h-6 rounded-full bg-cyan-500/10 border border-cyan-500/20 flex items-center justify-center">
                        <span className="text-[9px] font-bold text-cyan-300">
                          {(user.name || "U").charAt(0).toUpperCase()}
                        </span>
                      </div>
                      <span className="text-xs text-cyan-200/70">{user.name || "Anonymous"}</span>
                    </div>
                  </td>
                  <td className="px-4 py-3 text-xs text-cyan-200/40">
                    {user.email || "—"}
                  </td>
                  <td className="px-4 py-3">
                    <span
                      className={`inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[9px] font-mono-telemetry ${
                        user.userType === "oauth"
                          ? "bg-emerald-500/10 text-emerald-400/60 border border-emerald-500/20"
                          : "bg-amber-500/10 text-amber-400/60 border border-amber-500/20"
                      }`}
                    >
                      {user.userType.toUpperCase()}
                    </span>
                  </td>
                  <td className="px-4 py-3">
                    <span
                      className={`inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[9px] font-mono-telemetry ${
                        user.role === "admin"
                          ? "bg-cyan-500/10 text-cyan-400/60 border border-cyan-500/20"
                          : "bg-cyan-500/5 text-cyan-400/30 border border-cyan-500/10"
                      }`}
                    >
                      {user.role === "admin" && <Crown className="w-2.5 h-2.5" />}
                      {user.role.toUpperCase()}
                    </span>
                  </td>
                  <td className="px-4 py-3">
                    <button
                      onClick={() => {
                        updateRole.mutate({
                          id: user.id,
                          userType: user.userType,
                          role: user.role === "admin" ? "user" : "admin",
                        });
                      }}
                      disabled={updateRole.isPending}
                      className="text-[10px] text-cyan-400/40 hover:text-cyan-300 transition-colors disabled:opacity-30"
                    >
                      {user.role === "admin" ? "Demote" : "Promote"}
                    </button>
                  </td>
                </motion.tr>
              ))}
            </tbody>
          </table>

          {(!usersData?.users || usersData.users.length === 0) && (
            <div className="text-center py-12 text-cyan-200/30 text-sm">
              No users found
            </div>
          )}
        </div>

        {/* Pagination */}
        {totalPages > 1 && (
          <div className="flex items-center justify-between mt-4">
            <span className="text-[11px] text-cyan-200/30">
              Page {page} of {totalPages}
            </span>
            <div className="flex items-center gap-2">
              <button
                onClick={() => setPage(Math.max(1, page - 1))}
                disabled={page === 1}
                className="p-1.5 rounded-lg glass-button disabled:opacity-30"
              >
                <ChevronLeft className="w-4 h-4" />
              </button>
              <button
                onClick={() => setPage(Math.min(totalPages, page + 1))}
                disabled={page === totalPages}
                className="p-1.5 rounded-lg glass-button disabled:opacity-30"
              >
                <ChevronRight className="w-4 h-4" />
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
