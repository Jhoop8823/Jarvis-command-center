import { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import {
  FileText,
  Plus,
  Pencil,
  Trash2,
  X,
  Check,
  Star,
  Sparkles,
} from "lucide-react";
import { trpc } from "@/providers/trpc";

export default function SystemPrompts() {
  const utils = trpc.useUtils();
  const [isCreating, setIsCreating] = useState(false);
  const [editingId, setEditingId] = useState<number | null>(null);
  const [name, setName] = useState("");
  const [content, setContent] = useState("");
  const [isDefault, setIsDefault] = useState(false);

  const { data: prompts, isLoading } = trpc.systemPrompt.list.useQuery();

  const createPrompt = trpc.systemPrompt.create.useMutation({
    onSuccess: () => {
      utils.systemPrompt.list.invalidate();
      resetForm();
    },
  });

  const updatePrompt = trpc.systemPrompt.update.useMutation({
    onSuccess: () => {
      utils.systemPrompt.list.invalidate();
      resetForm();
    },
  });

  const deletePrompt = trpc.systemPrompt.delete.useMutation({
    onSuccess: () => utils.systemPrompt.list.invalidate(),
  });

  const resetForm = () => {
    setIsCreating(false);
    setEditingId(null);
    setName("");
    setContent("");
    setIsDefault(false);
  };

  const startEdit = (prompt: { id: number; name: string; content: string; isDefault: boolean }) => {
    setEditingId(prompt.id);
    setName(prompt.name);
    setContent(prompt.content);
    setIsDefault(prompt.isDefault);
    setIsCreating(true);
  };

  const handleSubmit = () => {
    if (!name.trim() || !content.trim()) return;

    if (editingId) {
      updatePrompt.mutate({
        id: editingId,
        name: name.trim(),
        content: content.trim(),
        isDefault,
      });
    } else {
      createPrompt.mutate({
        name: name.trim(),
        content: content.trim(),
        isDefault,
      });
    }
  };

  if (isLoading) {
    return (
      <div className="h-full flex items-center justify-center">
        <div className="w-8 h-8 border-2 border-cyan-400/20 border-t-cyan-400 rounded-full animate-spin" />
      </div>
    );
  }

  return (
    <div className="h-full glass-panel rounded-xl overflow-hidden flex flex-col">
      {/* Header */}
      <div className="h-14 border-b border-cyan-500/10 flex items-center justify-between px-6">
        <div className="flex items-center gap-3">
          <FileText className="w-5 h-5 text-cyan-400/60" />
          <h1 className="text-lg font-semibold text-cyan-200">System Prompts</h1>
        </div>
        <button
          onClick={() => {
            if (isCreating && !editingId) {
              resetForm();
            } else {
              setIsCreating(true);
              setEditingId(null);
              setName("");
              setContent("");
              setIsDefault(false);
            }
          }}
          className="glass-button-primary px-3 py-1.5 rounded-lg flex items-center gap-1.5 text-xs"
        >
          {isCreating && !editingId ? (
            <>
              <X className="w-3.5 h-3.5" />
              Cancel
            </>
          ) : (
            <>
              <Plus className="w-3.5 h-3.5" />
              New Prompt
            </>
          )}
        </button>
      </div>

      {/* Content */}
      <div className="flex-1 overflow-auto p-4">
        {/* Create/Edit Form */}
        <AnimatePresence>
          {isCreating && (
            <motion.div
              initial={{ height: 0, opacity: 0 }}
              animate={{ height: "auto", opacity: 1 }}
              exit={{ height: 0, opacity: 0 }}
              transition={{ duration: 0.2 }}
              className="overflow-hidden mb-6"
            >
              <div className="glass-panel rounded-xl p-4 space-y-4">
                <div>
                  <label className="telemetry-text block mb-1.5">Name</label>
                  <input
                    type="text"
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                    className="w-full glass-input px-3 py-2 rounded-lg text-sm"
                    placeholder="e.g., Coding Assistant"
                  />
                </div>
                <div>
                  <label className="telemetry-text block mb-1.5">Content</label>
                  <textarea
                    value={content}
                    onChange={(e) => setContent(e.target.value)}
                    rows={5}
                    className="w-full glass-input px-3 py-2 rounded-lg text-sm resize-none"
                    placeholder="Enter the system prompt content..."
                  />
                </div>
                <div className="flex items-center justify-between">
                  <label className="flex items-center gap-2 cursor-pointer">
                    <input
                      type="checkbox"
                      checked={isDefault}
                      onChange={(e) => setIsDefault(e.target.checked)}
                      className="w-4 h-4 rounded border-cyan-500/30 bg-transparent checked:bg-cyan-500"
                    />
                    <span className="telemetry-text">Set as default</span>
                  </label>
                  <div className="flex gap-2">
                    <button
                      onClick={resetForm}
                      className="glass-button px-3 py-1.5 rounded-lg text-xs"
                    >
                      Cancel
                    </button>
                    <button
                      onClick={handleSubmit}
                      disabled={!name.trim() || !content.trim() || createPrompt.isPending || updatePrompt.isPending}
                      className="glass-button-primary px-3 py-1.5 rounded-lg text-xs flex items-center gap-1.5 disabled:opacity-50"
                    >
                      {(createPrompt.isPending || updatePrompt.isPending) ? (
                        <div className="w-3 h-3 border border-cyan-400/30 border-t-cyan-400 rounded-full animate-spin" />
                      ) : (
                        <Check className="w-3.5 h-3.5" />
                      )}
                      {editingId ? "Update" : "Create"}
                    </button>
                  </div>
                </div>
              </div>
            </motion.div>
          )}
        </AnimatePresence>

        {/* Prompts List */}
        <div className="grid gap-3">
          {prompts?.map((prompt, index) => (
            <motion.div
              key={prompt.id}
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: index * 0.05 }}
              className="glass-panel-hover rounded-xl p-4 group"
            >
              <div className="flex items-start justify-between mb-2">
                <div className="flex items-center gap-2">
                  <Sparkles className="w-4 h-4 text-cyan-400/50" />
                  <h3 className="text-sm font-medium text-cyan-200/80">
                    {prompt.name}
                  </h3>
                  {prompt.isDefault && (
                    <span className="flex items-center gap-0.5 px-1.5 py-0.5 rounded-full bg-amber-500/10 border border-amber-500/20 text-[9px] text-amber-400/70 font-mono-telemetry">
                      <Star className="w-2.5 h-2.5" />
                      DEFAULT
                    </span>
                  )}
                </div>
                <div className="flex items-center gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
                  <button
                    onClick={() => startEdit(prompt)}
                    className="p-1.5 rounded-lg hover:bg-cyan-500/10 text-cyan-400/40 hover:text-cyan-300 transition-all"
                  >
                    <Pencil className="w-3.5 h-3.5" />
                  </button>
                  <button
                    onClick={() => {
                      if (confirm("Delete this system prompt?")) {
                        deletePrompt.mutate({ id: prompt.id });
                      }
                    }}
                    className="p-1.5 rounded-lg hover:bg-red-500/10 text-cyan-400/40 hover:text-red-400 transition-all"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>
              <p className="text-[11px] text-cyan-100/40 leading-relaxed line-clamp-3">
                {prompt.content}
              </p>
            </motion.div>
          ))}

          {(!prompts || prompts.length === 0) && !isCreating && (
            <div className="text-center py-12">
              <FileText className="w-12 h-12 text-cyan-400/10 mx-auto mb-4" />
              <p className="text-sm text-cyan-200/40">No system prompts yet</p>
              <p className="text-xs text-cyan-400/20 mt-1">
                Create custom prompts to guide the AI&apos;s behavior
              </p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
