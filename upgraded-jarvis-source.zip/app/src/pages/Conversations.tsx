import { useNavigate } from "react-router";
import { motion } from "framer-motion";
import {
  MessageSquare,
  Trash2,
  ArrowRight,
  Clock,
  Sparkles,
} from "lucide-react";
import { trpc } from "@/providers/trpc";

export default function Conversations() {
  const navigate = useNavigate();
  const utils = trpc.useUtils();

  const { data: conversations, isLoading } = trpc.conversation.list.useQuery();
  const deleteConv = trpc.conversation.delete.useMutation({
    onSuccess: () => utils.conversation.list.invalidate(),
  });

  const formatDate = (date: Date | string) => {
    const d = new Date(date);
    return d.toLocaleDateString("en-US", {
      month: "short",
      day: "numeric",
      hour: "2-digit",
      minute: "2-digit",
    });
  };

  if (isLoading) {
    return (
      <div className="h-full flex items-center justify-center">
        <div className="w-8 h-8 border-2 border-cyan-400/20 border-t-cyan-400 rounded-full animate-spin" />
      </div>
    );
  }

  return (
    <div className="h-full glass-panel rounded-xl overflow-hidden flex flex-col">
      {/* Header */}
      <div className="h-14 border-b border-cyan-500/10 flex items-center px-6">
        <MessageSquare className="w-5 h-5 text-cyan-400/60 mr-3" />
        <h1 className="text-lg font-semibold text-cyan-200">Conversation History</h1>
        <span className="ml-auto telemetry-text">
          {conversations?.length || 0} TOTAL
        </span>
      </div>

      {/* Content */}
      <div className="flex-1 overflow-auto p-4">
        {conversations && conversations.length > 0 ? (
          <div className="grid gap-3">
            {conversations.map((conv, index) => (
              <motion.div
                key={conv.id}
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: index * 0.05 }}
                className="glass-panel-hover rounded-xl p-4 flex items-center gap-4 group cursor-pointer"
                onClick={() => navigate(`/chat/${conv.id}`)}
              >
                <div className="w-10 h-10 rounded-lg bg-cyan-500/10 border border-cyan-500/20 flex items-center justify-center shrink-0">
                  <Sparkles className="w-5 h-5 text-cyan-400/60" />
                </div>

                <div className="flex-1 min-w-0">
                  <h3 className="text-sm font-medium text-cyan-200/80 truncate">
                    {conv.title}
                  </h3>
                  <div className="flex items-center gap-3 mt-1">
                    <span className="telemetry-text flex items-center gap-1">
                      <Clock className="w-2.5 h-2.5" />
                      {formatDate(conv.updatedAt)}
                    </span>
                    <span className="telemetry-text">{conv.model}</span>
                    <span className="telemetry-text">T: {conv.temperature}</span>
                  </div>
                </div>

                <div className="flex items-center gap-2 shrink-0">
                  <button
                    onClick={(e) => {
                      e.stopPropagation();
                      if (confirm("Delete this conversation?")) {
                        deleteConv.mutate({ id: conv.id });
                      }
                    }}
                    className="p-2 rounded-lg text-cyan-400/20 hover:text-red-400 hover:bg-red-500/10 transition-all opacity-0 group-hover:opacity-100"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                  <ArrowRight className="w-4 h-4 text-cyan-400/30 group-hover:text-cyan-300 transition-colors" />
                </div>
              </motion.div>
            ))}
          </div>
        ) : (
          <div className="h-full flex items-center justify-center">
            <div className="text-center">
              <MessageSquare className="w-12 h-12 text-cyan-400/10 mx-auto mb-4" />
              <p className="text-sm text-cyan-200/40">No conversations yet</p>
              <p className="text-xs text-cyan-400/20 mt-1">
                Start a new chat from the Command Center
              </p>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
