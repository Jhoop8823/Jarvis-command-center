import { useState, useRef, useEffect, useCallback } from "react";
import { useParams, useNavigate } from "react-router";
import { motion, AnimatePresence } from "framer-motion";
import {
  Send,
  Bot,
  User,
  Settings2,
  Loader2,
  Sparkles,
  Thermometer,
  Hash,
  ChevronDown,
  MessageSquarePlus,
  Trash2,
  Edit3,
} from "lucide-react";
import { trpc } from "@/providers/trpc";
import ReactMarkdown from "react-markdown";
import remarkGfm from "remark-gfm";

const MODELS = [
  { id: "gpt-4o", name: "GPT-4o", provider: "openai" },
  { id: "gpt-4o-mini", name: "GPT-4o Mini", provider: "openai" },
  { id: "claude-3-5-sonnet-20241022", name: "Claude 3.5 Sonnet", provider: "anthropic" },
  { id: "claude-3-7-sonnet-20250219", name: "Claude 3.7 Sonnet", provider: "anthropic" },
  { id: "gemini-1.5-pro-latest", name: "Gemini 1.5 Pro", provider: "google" },
] as const;

export default function Chat() {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const chatContainerRef = useRef<HTMLDivElement>(null);

  const [input, setInput] = useState("");
  const [streamingText, setStreamingText] = useState("");
  const [isStreaming, setIsStreaming] = useState(false);
  const [showControls, setShowControls] = useState(false);
  const [selectedModel, setSelectedModel] = useState("gpt-4o");
  const [temperature, setTemperature] = useState(0.7);
  const [maxTokens, setMaxTokens] = useState(2048);
  const [editingTitle, setEditingTitle] = useState<number | null>(null);
  const [editTitleValue, setEditTitleValue] = useState("");

  const utils = trpc.useUtils();

  const conversationId = id ? parseInt(id) : null;

  const { data: conversation } = trpc.conversation.getById.useQuery(
    { id: conversationId! },
    { enabled: !!conversationId },
  );

  const { data: conversations } = trpc.conversation.list.useQuery();
  const { data: systemPrompts } = trpc.systemPrompt.list.useQuery();

  const createConv = trpc.conversation.create.useMutation({
    onSuccess: (data) => {
      utils.conversation.list.invalidate();
      navigate(`/chat/${data.id}`);
    },
  });

  const updateConv = trpc.conversation.update.useMutation({
    onSuccess: () => {
      utils.conversation.list.invalidate();
      utils.conversation.getById.invalidate();
    },
  });

  const deleteConv = trpc.conversation.delete.useMutation({
    onSuccess: () => {
      utils.conversation.list.invalidate();
      navigate("/chat");
    },
  });

  const createMessage = trpc.message.create.useMutation();

  const scrollToBottom = useCallback(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, []);

  useEffect(() => {
    scrollToBottom();
  }, [conversation?.messages, streamingText, scrollToBottom]);

  const handleSend = async () => {
    if (!input.trim() || isStreaming) return;

    const message = input.trim();
    setInput("");

    let convId = conversationId;

    // Create new conversation if none exists
    if (!convId) {
      const newConv = await createConv.mutateAsync({
        title: message.slice(0, 50) + (message.length > 50 ? "..." : ""),
        model: selectedModel,
        temperature,
        maxTokens,
      });
      convId = newConv.id;
    }

    // Save user message
    await createMessage.mutateAsync({
      conversationId: convId,
      role: "user",
      content: message,
    });

    utils.conversation.getById.invalidate({ id: convId });

    // Start streaming
    setIsStreaming(true);
    setStreamingText("");

    try {
      const response = await fetch("/api/trpc/chat.stream", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          ...(localStorage.getItem("local_auth_token")
            ? { "x-local-auth-token": localStorage.getItem("local_auth_token")! }
            : {}),
        },
        body: JSON.stringify({
          conversationId: convId,
          message,
          model: selectedModel,
          temperature,
          maxTokens,
        }),
        credentials: "include",
      });

      if (!response.ok) {
        const errorData = await response.json().catch(() => ({}));
        throw new Error(errorData.message || "Failed to get response");
      }

      const reader = response.body?.getReader();
      if (!reader) throw new Error("No response body");

      const decoder = new TextDecoder();
      let fullText = "";

      while (true) {
        const { done, value } = await reader.read();
        if (done) break;
        const chunk = decoder.decode(value, { stream: true });
        fullText += chunk;
        setStreamingText(fullText);
      }

      setIsStreaming(false);
      setStreamingText("");
      utils.conversation.getById.invalidate({ id: convId });
    } catch (error) {
      setIsStreaming(false);
      const errorMsg = error instanceof Error ? error.message : "An error occurred";
      setStreamingText(`[Error: ${errorMsg}]`);
      setTimeout(() => setStreamingText(""), 3000);
    }
  };

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault();
      handleSend();
    }
  };

  const startNewChat = () => {
    navigate("/chat");
    setInput("");
    setStreamingText("");
  };

  const handleDeleteConv = (convId: number) => {
    if (confirm("Delete this conversation?")) {
      deleteConv.mutate({ id: convId });
    }
  };

  const startEditTitle = (conv: { id: number; title: string }) => {
    setEditingTitle(conv.id);
    setEditTitleValue(conv.title);
  };

  const saveTitle = () => {
    if (editingTitle && editTitleValue.trim()) {
      updateConv.mutate({ id: editingTitle, title: editTitleValue.trim() });
    }
    setEditingTitle(null);
  };

  const allMessages = conversation?.messages || [];

  return (
    <div className="h-full flex gap-4">
      {/* Conversations Sidebar */}
      <div className="w-56 shrink-0 glass-panel rounded-xl flex flex-col overflow-hidden">
        <div className="p-3 border-b border-cyan-500/10">
          <button
            onClick={startNewChat}
            className="w-full glass-button-primary py-2 px-3 rounded-lg flex items-center justify-center gap-2 text-xs font-medium"
          >
            <MessageSquarePlus className="w-3.5 h-3.5" />
            New Command
          </button>
        </div>

        <div className="flex-1 overflow-auto p-2 space-y-1">
          {conversations?.map((conv) => (
            <div
              key={conv.id}
              className={`group flex items-center gap-2 px-2.5 py-2 rounded-lg cursor-pointer transition-all ${
                conversationId === conv.id
                  ? "bg-cyan-500/10 border border-cyan-500/20"
                  : "hover:bg-cyan-500/5 border border-transparent"
              }`}
              onClick={() => navigate(`/chat/${conv.id}`)}
            >
              <div className="w-1.5 h-1.5 rounded-full bg-cyan-400/40 shrink-0" />
              {editingTitle === conv.id ? (
                <input
                  type="text"
                  value={editTitleValue}
                  onChange={(e) => setEditTitleValue(e.target.value)}
                  onBlur={saveTitle}
                  onKeyDown={(e) => e.key === "Enter" && saveTitle()}
                  autoFocus
                  className="flex-1 glass-input px-1.5 py-0.5 rounded text-[11px]"
                  onClick={(e) => e.stopPropagation()}
                />
              ) : (
                <span className="flex-1 text-[11px] text-cyan-200/70 truncate">
                  {conv.title}
                </span>
              )}
              <div className="flex items-center gap-0.5 opacity-0 group-hover:opacity-100 transition-opacity">
                <button
                  onClick={(e) => {
                    e.stopPropagation();
                    startEditTitle(conv);
                  }}
                  className="p-1 rounded hover:bg-cyan-500/10 text-cyan-400/40 hover:text-cyan-300"
                >
                  <Edit3 className="w-3 h-3" />
                </button>
                <button
                  onClick={(e) => {
                    e.stopPropagation();
                    handleDeleteConv(conv.id);
                  }}
                  className="p-1 rounded hover:bg-red-500/10 text-cyan-400/40 hover:text-red-400"
                >
                  <Trash2 className="w-3 h-3" />
                </button>
              </div>
            </div>
          ))}
          {(!conversations || conversations.length === 0) && (
            <div className="text-center py-8 text-cyan-400/20 text-[11px]">
              No conversations yet
            </div>
          )}
        </div>
      </div>

      {/* Main Chat Area */}
      <div className="flex-1 glass-panel rounded-xl flex flex-col overflow-hidden">
        {/* Chat Header */}
        <div className="h-12 border-b border-cyan-500/10 flex items-center justify-between px-4 shrink-0">
          <div className="flex items-center gap-3">
            <img src="/jarvis-avatar.png" alt="JARVIS" className="w-7 h-7 rounded-full" />
            <div>
              <h2 className="text-sm font-medium text-cyan-200">
                {conversation?.title || "Command Center"}
              </h2>
              <p className="text-[9px] text-cyan-400/40 font-mono-telemetry">
                {MODELS.find((m) => m.id === (conversation?.model || selectedModel))?.name || "GPT-4o"}
              </p>
            </div>
          </div>

          <button
            onClick={() => setShowControls(!showControls)}
            className={`p-2 rounded-lg transition-all ${
              showControls
                ? "bg-cyan-500/10 text-cyan-300 border border-cyan-500/20"
                : "text-cyan-400/40 hover:text-cyan-300 hover:bg-cyan-500/5"
            }`}
          >
            <Settings2 className="w-4 h-4" />
          </button>
        </div>

        {/* Controls Panel */}
        <AnimatePresence>
          {showControls && (
            <motion.div
              initial={{ height: 0, opacity: 0 }}
              animate={{ height: "auto", opacity: 1 }}
              exit={{ height: 0, opacity: 0 }}
              transition={{ duration: 0.2 }}
              className="overflow-hidden border-b border-cyan-500/10"
            >
              <div className="p-4 flex gap-4 flex-wrap">
                {/* Model Selector */}
                <div className="flex-1 min-w-[200px]">
                  <label className="telemetry-text block mb-1.5">AI Model</label>
                  <div className="relative">
                    <select
                      value={conversation?.model || selectedModel}
                      onChange={(e) => {
                        setSelectedModel(e.target.value);
                        if (conversationId) {
                          updateConv.mutate({ id: conversationId, model: e.target.value });
                        }
                      }}
                      className="w-full glass-input px-3 py-2 rounded-lg text-xs appearance-none pr-8"
                    >
                      {MODELS.map((m) => (
                        <option key={m.id} value={m.id}>
                          {m.name}
                        </option>
                      ))}
                    </select>
                    <ChevronDown className="absolute right-2.5 top-1/2 -translate-y-1/2 w-3.5 h-3.5 text-cyan-400/40 pointer-events-none" />
                  </div>
                </div>

                {/* Temperature */}
                <div className="flex-1 min-w-[150px]">
                  <label className="telemetry-text block mb-1.5 flex items-center gap-1">
                    <Thermometer className="w-3 h-3" />
                    Temperature: {temperature}
                  </label>
                  <input
                    type="range"
                    min={0}
                    max={2}
                    step={0.1}
                    value={temperature}
                    onChange={(e) => {
                      const val = parseFloat(e.target.value);
                      setTemperature(val);
                      if (conversationId) {
                        updateConv.mutate({ id: conversationId, temperature: val });
                      }
                    }}
                    className="w-full h-1.5 bg-cyan-500/10 rounded-full appearance-none cursor-pointer
                      [&::-webkit-slider-thumb]:appearance-none [&::-webkit-slider-thumb]:w-3.5 [&::-webkit-slider-thumb]:h-3.5
                      [&::-webkit-slider-thumb]:rounded-full [&::-webkit-slider-thumb]:bg-cyan-400
                      [&::-webkit-slider-thumb]:shadow-[0_0_10px_rgba(6,182,212,0.5)]"
                  />
                </div>

                {/* Max Tokens */}
                <div className="flex-1 min-w-[150px]">
                  <label className="telemetry-text block mb-1.5 flex items-center gap-1">
                    <Hash className="w-3 h-3" />
                    Max Tokens: {maxTokens}
                  </label>
                  <input
                    type="range"
                    min={256}
                    max={8192}
                    step={256}
                    value={maxTokens}
                    onChange={(e) => {
                      const val = parseInt(e.target.value);
                      setMaxTokens(val);
                      if (conversationId) {
                        updateConv.mutate({ id: conversationId, maxTokens: val });
                      }
                    }}
                    className="w-full h-1.5 bg-cyan-500/10 rounded-full appearance-none cursor-pointer
                      [&::-webkit-slider-thumb]:appearance-none [&::-webkit-slider-thumb]:w-3.5 [&::-webkit-slider-thumb]:h-3.5
                      [&::-webkit-slider-thumb]:rounded-full [&::-webkit-slider-thumb]:bg-cyan-400
                      [&::-webkit-slider-thumb]:shadow-[0_0_10px_rgba(6,182,212,0.5)]"
                  />
                </div>

                {/* System Prompt */}
                <div className="flex-1 min-w-[200px]">
                  <label className="telemetry-text block mb-1.5">System Prompt</label>
                  <div className="relative">
                    <select
                      value={conversation?.systemPromptId || ""}
                      onChange={(e) => {
                        const val = e.target.value ? parseInt(e.target.value) : null;
                        if (conversationId) {
                          updateConv.mutate({ id: conversationId, systemPromptId: val });
                        }
                      }}
                      className="w-full glass-input px-3 py-2 rounded-lg text-xs appearance-none pr-8"
                    >
                      <option value="">Default</option>
                      {systemPrompts?.map((sp) => (
                        <option key={sp.id} value={sp.id}>
                          {sp.name}
                        </option>
                      ))}
                    </select>
                    <ChevronDown className="absolute right-2.5 top-1/2 -translate-y-1/2 w-3.5 h-3.5 text-cyan-400/40 pointer-events-none" />
                  </div>
                </div>
              </div>
            </motion.div>
          )}
        </AnimatePresence>

        {/* Messages */}
        <div
          ref={chatContainerRef}
          className="flex-1 overflow-auto p-4 space-y-4"
        >
          {allMessages.length === 0 && !isStreaming && (
            <div className="h-full flex items-center justify-center">
              <div className="text-center">
                <motion.div
                  initial={{ scale: 0 }}
                  animate={{ scale: 1 }}
                  transition={{ type: "spring", stiffness: 200 }}
                  className="w-24 h-24 mx-auto mb-6 rounded-full bg-cyan-500/5 border border-cyan-500/10 flex items-center justify-center"
                >
                  <img src="/hud-core.png" alt="HUD" className="w-20 h-20 object-contain opacity-60" />
                </motion.div>
                <h3 className="text-lg font-medium text-cyan-200/80 mb-2">
                  J.A.R.V.I.S Online
                </h3>
                <p className="text-xs text-cyan-400/30 max-w-xs mx-auto">
                  I am your AI assistant. How may I assist you today?
                </p>
                <div className="mt-6 flex flex-wrap gap-2 justify-center">
                  {[
                    "Analyze this data",
                    "Help me code",
                    "Explain a concept",
                    "Write a plan",
                  ].map((suggestion) => (
                    <button
                      key={suggestion}
                      onClick={() => {
                        setInput(suggestion);
                      }}
                      className="px-3 py-1.5 rounded-lg bg-cyan-500/5 border border-cyan-500/10
                        text-[11px] text-cyan-300/60 hover:text-cyan-200 hover:bg-cyan-500/10
                        hover:border-cyan-500/20 transition-all"
                    >
                      {suggestion}
                    </button>
                  ))}
                </div>
              </div>
            </div>
          )}

          {allMessages.map((msg, index) => (
            <motion.div
              key={msg.id}
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.3, delay: index * 0.05 }}
              className={`flex gap-3 ${msg.role === "user" ? "flex-row-reverse" : ""}`}
            >
              <div
                className={`w-7 h-7 rounded-full flex items-center justify-center shrink-0 ${
                  msg.role === "user"
                    ? "bg-cyan-500/20 border border-cyan-500/30"
                    : "bg-cyan-400/10 border border-cyan-400/20"
                }`}
              >
                {msg.role === "user" ? (
                  <User className="w-3.5 h-3.5 text-cyan-300" />
                ) : (
                  <Bot className="w-3.5 h-3.5 text-cyan-400" />
                )}
              </div>

              <div
                className={`max-w-[80%] px-4 py-3 rounded-xl ${
                  msg.role === "user"
                    ? "bg-cyan-500/10 border border-cyan-500/15"
                    : "bg-[#0d1520]/60 border border-cyan-500/8"
                }`}
              >
                <div className="text-xs text-cyan-100/80 leading-relaxed prose prose-invert prose-sm max-w-none">
                  <ReactMarkdown remarkPlugins={[remarkGfm]}>
                    {msg.content}
                  </ReactMarkdown>
                </div>
              </div>
            </motion.div>
          ))}

          {/* Streaming message */}
          {isStreaming && streamingText && (
            <motion.div
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              className="flex gap-3"
            >
              <div className="w-7 h-7 rounded-full bg-cyan-400/10 border border-cyan-400/20 flex items-center justify-center shrink-0">
                <Sparkles className="w-3.5 h-3.5 text-cyan-400 animate-pulse" />
              </div>
              <div className="max-w-[80%] px-4 py-3 rounded-xl bg-[#0d1520]/60 border border-cyan-500/8">
                <div className="text-xs text-cyan-100/80 leading-relaxed prose prose-invert prose-sm max-w-none">
                  <ReactMarkdown remarkPlugins={[remarkGfm]}>
                    {streamingText}
                  </ReactMarkdown>
                </div>
              </div>
            </motion.div>
          )}

          {isStreaming && !streamingText && (
            <div className="flex gap-3">
              <div className="w-7 h-7 rounded-full bg-cyan-400/10 border border-cyan-400/20 flex items-center justify-center shrink-0">
                <Loader2 className="w-3.5 h-3.5 text-cyan-400 animate-spin" />
              </div>
              <div className="px-4 py-3 rounded-xl bg-[#0d1520]/60 border border-cyan-500/8">
                <div className="flex items-center gap-2">
                  <div className="w-1.5 h-1.5 rounded-full bg-cyan-400/60 animate-bounce" style={{ animationDelay: "0ms" }} />
                  <div className="w-1.5 h-1.5 rounded-full bg-cyan-400/60 animate-bounce" style={{ animationDelay: "150ms" }} />
                  <div className="w-1.5 h-1.5 rounded-full bg-cyan-400/60 animate-bounce" style={{ animationDelay: "300ms" }} />
                </div>
              </div>
            </div>
          )}

          <div ref={messagesEndRef} />
        </div>

        {/* Input Area */}
        <div className="p-3 border-t border-cyan-500/10 shrink-0">
          <div className="flex items-end gap-2">
            <div className="flex-1 relative">
              <textarea
                value={input}
                onChange={(e) => setInput(e.target.value)}
                onKeyDown={handleKeyDown}
                placeholder="Enter command..."
                rows={1}
                className="w-full glass-input px-4 py-3 rounded-xl text-sm resize-none min-h-[44px] max-h-32"
                style={{ overflow: "auto" }}
              />
            </div>
            <motion.button
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
              onClick={handleSend}
              disabled={!input.trim() || isStreaming}
              className="h-11 w-11 glass-button-primary rounded-xl flex items-center justify-center shrink-0 disabled:opacity-30"
            >
              {isStreaming ? (
                <Loader2 className="w-4 h-4 animate-spin" />
              ) : (
                <Send className="w-4 h-4" />
              )}
            </motion.button>
          </div>
        </div>
      </div>
    </div>
  );
}
