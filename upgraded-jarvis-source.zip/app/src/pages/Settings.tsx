import { useState } from "react";
import { motion } from "framer-motion";
import {
  Settings2,
  User,
  Key,
  FileText,
  AlertTriangle,
} from "lucide-react";
import { useAuth } from "@/hooks/useAuth";
import { trpc } from "@/providers/trpc";
import { useNavigate } from "react-router";

export default function Settings() {
  const { user, logout } = useAuth();
  const navigate = useNavigate();
  const utils = trpc.useUtils();
  const [showDeleteConfirm, setShowDeleteConfirm] = useState(false);

  const { data: conversations } = trpc.conversation.list.useQuery();

  const deleteConv = trpc.conversation.delete.useMutation({
    onSuccess: () => {
      utils.conversation.list.invalidate();
    },
  });

  return (
    <div className="h-full glass-panel rounded-xl overflow-hidden flex flex-col">
      {/* Header */}
      <div className="h-14 border-b border-cyan-500/10 flex items-center px-6">
        <Settings2 className="w-5 h-5 text-cyan-400/60 mr-3" />
        <h1 className="text-lg font-semibold text-cyan-200">Settings</h1>
      </div>

      {/* Content */}
      <div className="flex-1 overflow-auto p-6 max-w-2xl mx-auto w-full">
        {/* Profile Section */}
        <motion.div
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          className="glass-panel rounded-xl p-5 mb-4"
        >
          <h2 className="text-sm font-semibold text-cyan-200 mb-4 flex items-center gap-2">
            <User className="w-4 h-4 text-cyan-400/50" />
            Profile
          </h2>
          <div className="flex items-center gap-4">
            <div className="w-14 h-14 rounded-full bg-cyan-500/10 border border-cyan-500/20 flex items-center justify-center">
              <span className="text-lg font-bold text-cyan-300">
                {user?.name?.charAt(0).toUpperCase() || "U"}
              </span>
            </div>
            <div>
              <p className="text-sm text-cyan-200/80">{user?.name}</p>
              <p className="text-xs text-cyan-400/30 font-mono-telemetry mt-0.5">
                {user?.authType?.toUpperCase()} ACCOUNT
              </p>
              {user?.email && (
                <p className="text-xs text-cyan-200/40 mt-0.5">{user.email}</p>
              )}
            </div>
          </div>
        </motion.div>

        {/* Quick Links */}
        <motion.div
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.1 }}
          className="glass-panel rounded-xl p-5 mb-4"
        >
          <h2 className="text-sm font-semibold text-cyan-200 mb-4">Quick Links</h2>
          <div className="grid grid-cols-2 gap-3">
            <button
              onClick={() => navigate("/api-keys")}
              className="glass-panel-hover rounded-lg p-3 flex items-center gap-3 text-left transition-all"
            >
              <Key className="w-4 h-4 text-cyan-400/50" />
              <div>
                <p className="text-xs text-cyan-200/70">API Keys</p>
                <p className="text-[10px] text-cyan-400/20">Manage provider keys</p>
              </div>
            </button>
            <button
              onClick={() => navigate("/prompts")}
              className="glass-panel-hover rounded-lg p-3 flex items-center gap-3 text-left transition-all"
            >
              <FileText className="w-4 h-4 text-cyan-400/50" />
              <div>
                <p className="text-xs text-cyan-200/70">System Prompts</p>
                <p className="text-[10px] text-cyan-400/20">Custom AI behavior</p>
              </div>
            </button>
          </div>
        </motion.div>

        {/* Danger Zone */}
        <motion.div
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2 }}
          className="glass-panel rounded-xl p-5 border-red-500/10"
        >
          <h2 className="text-sm font-semibold text-red-300/60 mb-4 flex items-center gap-2">
            <AlertTriangle className="w-4 h-4" />
            Danger Zone
          </h2>

          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-xs text-cyan-200/60">Sign Out</p>
                <p className="text-[10px] text-cyan-400/20">End your current session</p>
              </div>
              <button
                onClick={logout}
                className="px-3 py-1.5 rounded-lg bg-red-500/10 border border-red-500/20 text-red-400/60 hover:text-red-300 hover:bg-red-500/20 text-xs transition-all"
              >
                Sign Out
              </button>
            </div>

            <div className="h-px bg-cyan-500/5" />

            <div className="flex items-center justify-between">
              <div>
                <p className="text-xs text-cyan-200/60">Clear All Data</p>
                <p className="text-[10px] text-cyan-400/20">Delete all conversations and settings</p>
              </div>
              <button
                onClick={() => setShowDeleteConfirm(true)}
                className="px-3 py-1.5 rounded-lg bg-red-500/10 border border-red-500/20 text-red-400/60 hover:text-red-300 hover:bg-red-500/20 text-xs transition-all"
              >
                Clear Data
              </button>
            </div>
          </div>
        </motion.div>

        {/* Footer */}
        <div className="mt-6 text-center">
          <p className="text-[10px] text-cyan-400/15 font-mono-telemetry">
            J.A.R.V.I.S COMMAND CENTER v3.0.1
          </p>
        </div>
      </div>

      {/* Delete Confirmation Modal */}
      {showDeleteConfirm && (
        <div className="absolute inset-0 z-50 flex items-center justify-center bg-black/50 backdrop-blur-sm">
          <motion.div
            initial={{ scale: 0.95, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            className="glass-panel rounded-xl p-6 max-w-sm mx-4"
          >
            <h3 className="text-sm font-semibold text-red-300 mb-2">Clear All Data?</h3>
            <p className="text-xs text-cyan-200/40 mb-4">
              This will delete all your conversations, system prompts, and API keys. This action cannot be undone.
            </p>
            <div className="flex gap-2 justify-end">
              <button
                onClick={() => setShowDeleteConfirm(false)}
                className="glass-button px-3 py-1.5 rounded-lg text-xs"
              >
                Cancel
              </button>
              <button
                onClick={() => {
                  conversations?.forEach((conv: { id: number }) => {
                    deleteConv.mutate({ id: conv.id });
                  });
                  setShowDeleteConfirm(false);
                }}
                className="px-3 py-1.5 rounded-lg bg-red-500/20 border border-red-500/30 text-red-400 hover:bg-red-500/30 text-xs transition-all"
              >
                Confirm Delete
              </button>
            </div>
          </motion.div>
        </div>
      )}
    </div>
  );
}
