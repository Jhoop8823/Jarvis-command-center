import { useNavigate } from "react-router";
import { motion } from "framer-motion";
import { ArrowLeft, AlertCircle } from "lucide-react";

export default function NotFound() {
  const navigate = useNavigate();

  return (
    <div className="h-full flex items-center justify-center">
      <div className="text-center">
        <motion.div
          initial={{ scale: 0 }}
          animate={{ scale: 1 }}
          transition={{ type: "spring", stiffness: 200 }}
          className="w-20 h-20 mx-auto mb-6 rounded-full bg-cyan-500/5 border border-cyan-500/10 flex items-center justify-center"
        >
          <AlertCircle className="w-10 h-10 text-cyan-400/30" />
        </motion.div>
        <motion.h1
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.1 }}
          className="text-3xl font-bold text-cyan-200/40 mb-2 font-mono-telemetry"
        >
          404
        </motion.h1>
        <motion.p
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2 }}
          className="text-sm text-cyan-200/30 mb-6"
        >
          Sector not found. The requested resource does not exist.
        </motion.p>
        <motion.button
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.3 }}
          onClick={() => navigate("/")}
          className="glass-button px-4 py-2 rounded-lg text-xs flex items-center gap-2 mx-auto"
        >
          <ArrowLeft className="w-3.5 h-3.5" />
          Return to Command Center
        </motion.button>
      </div>
    </div>
  );
}
