import { Routes, Route, Navigate } from "react-router";
import { useAuth } from "@/hooks/useAuth";
import MainLayout from "@/components/MainLayout";
import Login from "@/pages/Login";
import Chat from "@/pages/Chat";
import Conversations from "@/pages/Conversations";
import SystemPrompts from "@/pages/SystemPrompts";
import ApiKeys from "@/pages/ApiKeys";
import AdminDashboard from "@/pages/AdminDashboard";
import Settings from "@/pages/Settings";
import NotFound from "@/pages/NotFound";

export default function App() {
  const { isAuthenticated, isLoading } = useAuth();

  if (isLoading) {
    return (
      <div className="h-screen w-full bg-[#0a0f1a] flex items-center justify-center">
        <div className="relative">
          <div className="w-16 h-16 rounded-full border-2 border-cyan-500/20 animate-spin">
            <div className="absolute top-0 left-1/2 w-1.5 h-1.5 -translate-x-1/2 -translate-y-0.5 rounded-full bg-cyan-400" />
          </div>
          <div className="absolute inset-0 flex items-center justify-center">
            <div className="w-2 h-2 rounded-full bg-cyan-400 animate-pulse" />
          </div>
        </div>
      </div>
    );
  }

  return (
    <Routes>
      <Route path="/login" element={<Login />} />
      <Route
        path="/*"
        element={
          isAuthenticated ? (
            <MainLayout>
              <Routes>
                <Route path="/" element={<Chat />} />
                <Route path="/chat" element={<Chat />} />
                <Route path="/chat/:id" element={<Chat />} />
                <Route path="/conversations" element={<Conversations />} />
                <Route path="/prompts" element={<SystemPrompts />} />
                <Route path="/api-keys" element={<ApiKeys />} />
                <Route path="/admin" element={<AdminDashboard />} />
                <Route path="/settings" element={<Settings />} />
                <Route path="*" element={<NotFound />} />
              </Routes>
            </MainLayout>
          ) : (
            <Navigate to="/login" replace />
          )
        }
      />
    </Routes>
  );
}
