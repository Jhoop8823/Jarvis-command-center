import { useEffect, useRef, useCallback } from "react";
import { motion, useMotionValue, useTransform } from "framer-motion";

interface Dot {
  x: number;
  y: number;
  size: number;
  opacity: number;
  vx: number;
  vy: number;
}

export default function ParallaxBackground() {
  const containerRef = useRef<HTMLDivElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const dotsRef = useRef<Dot[]>([]);
  const animRef = useRef<number>(0);
  const mouseRef = useRef({ x: 0, y: 0 });

  const mouseX = useMotionValue(0);
  const mouseY = useMotionValue(0);

  const bgX = useTransform(mouseX, [-500, 500], [-5, 5]);
  const bgY = useTransform(mouseY, [-500, 500], [-5, 5]);
  const midX = useTransform(mouseX, [-500, 500], [-10, 10]);
  const midY = useTransform(mouseY, [-500, 500], [-10, 10]);

  const initDots = useCallback((width: number, height: number) => {
    const dots: Dot[] = [];
    for (let i = 0; i < 60; i++) {
      dots.push({
        x: Math.random() * width,
        y: Math.random() * height,
        size: Math.random() * 1.5 + 0.5,
        opacity: Math.random() * 0.3 + 0.1,
        vx: (Math.random() - 0.5) * 0.15,
        vy: (Math.random() - 0.5) * 0.15,
      });
    }
    dotsRef.current = dots;
  }, []);

  useEffect(() => {
    const canvas = canvasRef.current;
    const container = containerRef.current;
    if (!canvas || !container) return;

    const ctx = canvas.getContext("2d");
    if (!ctx) return;

    const resize = () => {
      const w = container.offsetWidth;
      const h = container.offsetHeight;
      canvas.width = w * window.devicePixelRatio;
      canvas.height = h * window.devicePixelRatio;
      ctx.scale(window.devicePixelRatio, window.devicePixelRatio);
      if (dotsRef.current.length === 0) {
        initDots(w, h);
      }
    };

    resize();
    window.addEventListener("resize", resize);

    const handleMouseMove = (e: MouseEvent) => {
      const rect = container.getBoundingClientRect();
      mouseRef.current = {
        x: e.clientX - rect.left - rect.width / 2,
        y: e.clientY - rect.top - rect.height / 2,
      };
      mouseX.set(mouseRef.current.x);
      mouseY.set(mouseRef.current.y);
    };

    window.addEventListener("mousemove", handleMouseMove);

    const animate = () => {
      const w = container.offsetWidth;
      const h = container.offsetHeight;
      ctx.clearRect(0, 0, w, h);

      const dots = dotsRef.current;

      // Update and draw dots
      for (const dot of dots) {
        dot.x += dot.vx;
        dot.y += dot.vy;

        if (dot.x < 0 || dot.x > w) dot.vx *= -1;
        if (dot.y < 0 || dot.y > h) dot.vy *= -1;

        ctx.beginPath();
        ctx.arc(dot.x, dot.y, dot.size, 0, Math.PI * 2);
        ctx.fillStyle = `rgba(100, 200, 255, ${dot.opacity})`;
        ctx.fill();
      }

      // Draw connections
      ctx.strokeStyle = "rgba(6, 182, 212, 0.06)";
      ctx.lineWidth = 0.5;
      for (let i = 0; i < dots.length; i++) {
        for (let j = i + 1; j < dots.length; j++) {
          const dx = dots[i].x - dots[j].x;
          const dy = dots[i].y - dots[j].y;
          const dist = Math.sqrt(dx * dx + dy * dy);
          if (dist < 150) {
            ctx.beginPath();
            ctx.moveTo(dots[i].x, dots[i].y);
            ctx.lineTo(dots[j].x, dots[j].y);
            ctx.stroke();
          }
        }
      }

      animRef.current = requestAnimationFrame(animate);
    };

    animate();

    return () => {
      cancelAnimationFrame(animRef.current);
      window.removeEventListener("resize", resize);
      window.removeEventListener("mousemove", handleMouseMove);
    };
  }, [initDots, mouseX, mouseY]);

  return (
    <div ref={containerRef} className="absolute inset-0 overflow-hidden pointer-events-none">
      {/* Radial gradient base */}
      <div className="absolute inset-0 bg-gradient-radial from-[#0d1f30]/40 via-[#0a0f1a] to-[#0a0f1a]" />

      {/* Background layer - subtle dots */}
      <motion.div
        style={{ x: bgX, y: bgY }}
        className="absolute inset-0 will-change-transform"
      >
        {Array.from({ length: 40 }).map((_, i) => (
          <div
            key={`bg-${i}`}
            className="absolute rounded-full bg-cyan-400/[0.08]"
            style={{
              width: Math.random() * 2 + 1,
              height: Math.random() * 2 + 1,
              left: `${Math.random() * 100}%`,
              top: `${Math.random() * 100}%`,
            }}
          />
        ))}
      </motion.div>

      {/* Mid layer - canvas with connected dots */}
      <motion.div
        style={{ x: midX, y: midY }}
        className="absolute inset-0 will-change-transform"
      >
        <canvas
          ref={canvasRef}
          style={{
            position: "absolute",
            top: 0,
            left: 0,
            width: "100%",
            height: "100%",
          }}
        />
      </motion.div>

      {/* Front layer - telemetry labels */}
      <motion.div
        style={{
          x: useTransform(mouseX, [-500, 500], [-20, 20]),
          y: useTransform(mouseY, [-500, 500], [-20, 20]),
        }}
        className="absolute inset-0 will-change-transform"
      >
        {[
          { text: "SYS_PROCESS_01", x: 12, y: 25 },
          { text: "AI_THREAD_A", x: 78, y: 15 },
          { text: "NET_PROTOCOL", x: 85, y: 72 },
          { text: "MEM_ALLOC", x: 5, y: 65 },
          { text: "CORE_07", x: 45, y: 8 },
          { text: "STREAM_RX", x: 90, y: 40 },
        ].map((item, i) => (
          <div
            key={`front-${i}`}
            className="absolute font-mono-telemetry text-[9px] text-cyan-400/[0.25] tracking-widest"
            style={{
              left: `${item.x}%`,
              top: `${item.y}%`,
            }}
          >
            {item.text}
          </div>
        ))}
      </motion.div>

      {/* Subtle grid overlay */}
      <div
        className="absolute inset-0 opacity-[0.02]"
        style={{
          backgroundImage: `
            linear-gradient(rgba(6, 182, 212, 0.3) 1px, transparent 1px),
            linear-gradient(90deg, rgba(6, 182, 212, 0.3) 1px, transparent 1px)
          `,
          backgroundSize: "60px 60px",
        }}
      />
    </div>
  );
}
