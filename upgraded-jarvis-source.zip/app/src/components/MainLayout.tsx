import { useState, useEffect, useRef } from "react";
import { useLocation, useNavigate } from "react-router";
import { motion, AnimatePresence } from "framer-motion";
import {
  MessageSquare,
  History,
  FileText,
  Key,
  Settings,
  Shield,
  LogOut,
  ChevronLeft,
  ChevronRight,
  Cpu,
  Wifi,
  Lock,
  Zap,
} from "lucide-react";
import { useAuth } from "@/hooks/useAuth";
import ParallaxBackground from "./ParallaxBackground";
import type { ReactNode } from "react";

const navItems = [
  { path: "/", icon: MessageSquare, label: "Command Center" },
  { path: "/conversations", icon: History, label: "History" },
  { path: "/prompts", icon: FileText, label: "Prompts" },
  { path: "/api-keys", icon: Key, label: "API Keys" },
  { path: "/settings", icon: Settings, label: "Settings" },
];

export default function MainLayout({ children }: { children: ReactNode }) {
  const [sidebarOpen, setSidebarOpen] = useState(true);
  const [currentTime, setCurrentTime] = useState(new Date());
  const location = useLocation();
  const navigate = useNavigate();
  const { user, isAdmin, logout } = useAuth();
  const mainRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const timer = setInterval(() => setCurrentTime(new Date()), 1000);
    return () => clearInterval(timer);
  }, []);

  const formatTime = (date: Date) => {
    return date.toISOString().slice(11, 19) + " UTC";
  };

  return (
    <div className="h-screen w-full bg-[#0a0f1a] overflow-hidden relative">
      {/* Parallax Background */}
      <ParallaxBackground />

      {/* Scan Line Overlay */}
      <div className="scan-line opacity-30" />

      {/* Top Telemetry Bar */}
      <div className="absolute top-0 left-0 right-0 h-7 bg-[#0a0f1a]/90 backdrop-blur-sm border-b border-cyan-500/10 z-50 flex items-center justify-between px-4">
        <div className="flex items-center gap-6">
          <div className="flex items-center gap-1.5">
            <Cpu className="w-3 h-3 text-cyan-400/60" />
            <span className="telemetry-text">SYS_ACTIVE</span>
          </div>
          <div className="flex items-center gap-1.5">
            <Wifi className="w-3 h-3 text-emerald-400/60" />
            <span className="telemetry-text">NET_SECURE</span>
          </div>
          <div className="flex items-center gap-1.5">
            <Lock className="w-3 h-3 text-cyan-400/60" />
            <span className="telemetry-text">ENCRYPTED</span>
          </div>
        </div>
        <div className="flex items-center gap-6">
          <div className="flex items-center gap-1.5">
            <Zap className="w-3 h-3 text-amber-400/60" />
            <span className="telemetry-text">AI_CORE: ONLINE</span>
          </div>
          <span className="telemetry-text">{formatTime(currentTime)}</span>
        </div>
      </div>

      {/* Left Sidebar */}
      <motion.div
        initial={false}
        animate={{ width: sidebarOpen ? 220 : 64 }}
        transition={{ type: "spring", stiffness: 300, damping: 30 }}
        className="absolute left-0 top-7 bottom-0 z-40 flex flex-col border-r border-cyan-500/10 bg-[#0a0f1a]/80 backdrop-blur-xl"
      >
        {/* Sidebar Header */}
        <div className="h-14 flex items-center px-4 border-b border-cyan-500/10">
          <AnimatePresence>
            {sidebarOpen && (
              <motion.div
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                exit={{ opacity: 0 }}
                className="flex items-center gap-3 overflow-hidden"
              >
                <img
                  src="/jarvis-avatar.png"
                  alt="JARVIS"
                  className="w-8 h-8 rounded-full object-cover"
                />
                <div>
                  <h1 className="text-xs font-semibold text-cyan-300 tracking-wider whitespace-nowrap">
                    J.A.R.V.I.S
                  </h1>
                  <p className="text-[9px] text-cyan-500/50 tracking-wider whitespace-nowrap font-mono-telemetry">
                    v3.0.1
                  </p>
                </div>
              </motion.div>
            )}
          </AnimatePresence>
          {!sidebarOpen && (
            <img
              src="/jarvis-avatar.png"
              alt="JARVIS"
              className="w-8 h-8 rounded-full object-cover mx-auto"
            />
          )}
        </div>

        {/* Navigation */}
        <nav className="flex-1 py-4 px-2 space-y-1">
          {navItems.map((item) => {
            const isActive = location.pathname === item.path ||
              (item.path === "/" && location.pathname.startsWith("/chat"));
            return (
              <button
                key={item.path}
                onClick={() => navigate(item.path)}
                className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-lg transition-all duration-200 group relative ${
                  isActive
                    ? "bg-cyan-500/10 text-cyan-300 border border-cyan-500/20"
                    : "text-cyan-100/40 hover:text-cyan-200/70 hover:bg-cyan-500/5 border border-transparent"
                }`}
              >
                {isActive && (
                  <motion.div
                    layoutId="activeNav"
                    className="absolute left-0 top-1/2 -translate-y-1/2 w-0.5 h-5 bg-cyan-400 rounded-r-full"
                    transition={{ type: "spring", stiffness: 300, damping: 30 }}
                  />
                )}
                <item.icon className="w-[18px] h-[18px] shrink-0" />
                <AnimatePresence>
                  {sidebarOpen && (
                    <motion.span
                      initial={{ opacity: 0, width: 0 }}
                      animate={{ opacity: 1, width: "auto" }}
                      exit={{ opacity: 0, width: 0 }}
                      className="text-xs font-medium whitespace-nowrap overflow-hidden"
                    >
                      {item.label}
                    </motion.span>
                  )}
                </AnimatePresence>
              </button>
            );
          })}

          {isAdmin && (
            <button
              onClick={() => navigate("/admin")}
              className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-lg transition-all duration-200 group relative ${
                location.pathname === "/admin"
                  ? "bg-cyan-500/10 text-cyan-300 border border-cyan-500/20"
                  : "text-cyan-100/40 hover:text-cyan-200/70 hover:bg-cyan-500/5 border border-transparent"
              }`}
            >
              {location.pathname === "/admin" && (
                <motion.div
                  layoutId="activeNav"
                  className="absolute left-0 top-1/2 -translate-y-1/2 w-0.5 h-5 bg-cyan-400 rounded-r-full"
                  transition={{ type: "spring", stiffness: 300, damping: 30 }}
                />
              )}
              <Shield className="w-[18px] h-[18px] shrink-0" />
              <AnimatePresence>
                {sidebarOpen && (
                  <motion.span
                    initial={{ opacity: 0, width: 0 }}
                    animate={{ opacity: 1, width: "auto" }}
                    exit={{ opacity: 0, width: 0 }}
                    className="text-xs font-medium whitespace-nowrap overflow-hidden"
                  >
                    Admin
                  </motion.span>
                )}
              </AnimatePresence>
            </button>
          )}
        </nav>

        {/* User Section */}
        <div className="border-t border-cyan-500/10 p-2">
          <div className="flex items-center gap-2 px-2 py-2">
            <div className="w-7 h-7 rounded-full bg-cyan-500/20 border border-cyan-500/30 flex items-center justify-center shrink-0">
              <span className="text-[10px] font-bold text-cyan-300">
                {user?.name?.charAt(0).toUpperCase() || "U"}
              </span>
            </div>
            <AnimatePresence>
              {sidebarOpen && (
                <motion.div
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  exit={{ opacity: 0 }}
                  className="flex-1 min-w-0 overflow-hidden"
                >
                  <p className="text-[11px] text-cyan-200/80 truncate">{user?.name}</p>
                  <p className="text-[9px] text-cyan-500/40 font-mono-telemetry uppercase">
                    {user?.authType}
                  </p>
                </motion.div>
              )}
            </AnimatePresence>
          </div>
          <button
            onClick={logout}
            className="w-full flex items-center gap-3 px-3 py-2 rounded-lg text-cyan-100/30 hover:text-red-400/70 hover:bg-red-500/5 transition-all duration-200"
          >
            <LogOut className="w-[16px] h-[16px] shrink-0" />
            <AnimatePresence>
              {sidebarOpen && (
                <motion.span
                  initial={{ opacity: 0, width: 0 }}
                  animate={{ opacity: 1, width: "auto" }}
                  exit={{ opacity: 0, width: 0 }}
                  className="text-[11px] font-medium whitespace-nowrap overflow-hidden"
                >
                  Sign Out
                </motion.span>
              )}
            </AnimatePresence>
          </button>
        </div>

        {/* Toggle Button */}
        <button
          onClick={() => setSidebarOpen(!sidebarOpen)}
          className="absolute -right-3 top-20 w-6 h-6 rounded-full bg-[#0d1520] border border-cyan-500/20 flex items-center justify-center text-cyan-400/60 hover:text-cyan-300 hover:border-cyan-400/40 transition-all z-50"
        >
          {sidebarOpen ? <ChevronLeft className="w-3 h-3" /> : <ChevronRight className="w-3 h-3" />}
        </button>
      </motion.div>

      {/* Main Content */}
      <motion.main
        ref={mainRef}
        initial={false}
        animate={{ paddingLeft: sidebarOpen ? 220 : 64 }}
        transition={{ type: "spring", stiffness: 300, damping: 30 }}
        className="h-full pt-7 overflow-hidden"
      >
        <div className="h-full overflow-auto p-4">
          {children}
        </div>
      </motion.main>
    </div>
  );
}
