import * as jose from "jose";
import { eq } from "drizzle-orm";
import { env } from "./lib/env";
import { getDb } from "./queries/connection";
import { localUsers } from "@db/schema";
import type { LocalUser } from "@db/schema";

const JWT_ALG = "HS256";
const LOCAL_JWT_SECRET = () => new TextEncoder().encode(env.appSecret + "_local");

export async function signLocalToken(userId: number, username: string): Promise<string> {
  return new jose.SignJWT({ userId, username, type: "local" })
    .setProtectedHeader({ alg: JWT_ALG })
    .setIssuedAt()
    .setExpirationTime("30d")
    .sign(LOCAL_JWT_SECRET());
}

export async function verifyLocalToken(token: string): Promise<LocalUser | null> {
  try {
    const { payload } = await jose.jwtVerify(token, LOCAL_JWT_SECRET(), {
      algorithms: [JWT_ALG],
      clockTolerance: 60,
    });
    const userId = payload.userId as number;
    if (!userId) return null;

    const rows = await getDb()
      .select()
      .from(localUsers)
      .where(eq(localUsers.id, userId))
      .limit(1);

    return rows.at(0) ?? null;
  } catch {
    return null;
  }
}
