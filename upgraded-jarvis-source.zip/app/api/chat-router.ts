import { z } from "zod";
import { eq, and, desc } from "drizzle-orm";
import { TRPCError } from "@trpc/server";
import { OpenAI } from "openai";
import Anthropic from "@anthropic-ai/sdk";
import { GoogleGenerativeAI } from "@google/generative-ai";
import { createRouter, authedQuery } from "./middleware";
import { getDb } from "./queries/connection";
import { conversations, messages, apiKeys } from "@db/schema";
import type { AIProvider } from "@contracts/types";
import CryptoJS from "crypto-js";

const ENCRYPTION_KEY = process.env.APP_SECRET || "jarvis-fallback-key";

function decryptKey(encryptedValue: string): string {
  const bytes = CryptoJS.AES.decrypt(encryptedValue, ENCRYPTION_KEY);
  return bytes.toString(CryptoJS.enc.Utf8);
}

function getProviderFromModel(model: string): AIProvider {
  if (model.startsWith("gpt-")) return "openai";
  if (model.startsWith("claude-")) return "anthropic";
  if (model.startsWith("gemini-")) return "google";
  return "openai";
}

export const chatRouter = createRouter({
  stream: authedQuery
    .input(
      z.object({
        conversationId: z.number(),
        message: z.string(),
        model: z.string().optional(),
        temperature: z.number().optional(),
        maxTokens: z.number().optional(),
      }),
    )
    .mutation(async ({ ctx, input }) => {
      const user = ctx.unifiedUser;

      // Get conversation
      const convRows = await getDb()
        .select()
        .from(conversations)
        .where(
          and(
            eq(conversations.id, input.conversationId),
            eq(conversations.userId, user.id),
            eq(conversations.userType, user.authType),
          ),
        )
        .limit(1);

      const conv = convRows.at(0);
      if (!conv) {
        throw new TRPCError({ code: "NOT_FOUND", message: "Conversation not found" });
      }

      // Save user message
      await getDb().insert(messages).values({
        conversationId: input.conversationId,
        role: "user",
        content: input.message,
      });

      // Get conversation history
      const history = await getDb()
        .select()
        .from(messages)
        .where(eq(messages.conversationId, input.conversationId))
        .orderBy(desc(messages.createdAt))
        .limit(20);

      const sortedHistory = history.reverse();

      const model = input.model || conv.model;
      const provider = getProviderFromModel(model);

      // Get API key
      const keyRows = await getDb()
        .select()
        .from(apiKeys)
        .where(
          and(
            eq(apiKeys.userId, user.id),
            eq(apiKeys.userType, user.authType),
            eq(apiKeys.provider, provider),
          ),
        )
        .limit(1);

      const apiKeyRecord = keyRows.at(0);
      if (!apiKeyRecord) {
        throw new TRPCError({
          code: "BAD_REQUEST",
          message: `No API key found for ${provider}. Please add your API key in settings.`,
        });
      }

      const apiKey = decryptKey(apiKeyRecord.keyValue);
      const temperature = input.temperature ?? Number(conv.temperature);
      const maxTokens = input.maxTokens ?? conv.maxTokens;

      // Build message history for the provider
      const chatMessages = sortedHistory.map((m) => ({
        role: m.role as "user" | "assistant" | "system",
        content: m.content,
      }));

      // Stream based on provider
      const stream = new ReadableStream({
        async start(controller) {
          try {
            let fullResponse = "";

            if (provider === "openai") {
              const openai = new OpenAI({ apiKey });
              const completion = await openai.chat.completions.create({
                model,
                messages: chatMessages,
                temperature,
                max_tokens: maxTokens,
                stream: true,
              });

              for await (const chunk of completion) {
                const content = chunk.choices[0]?.delta?.content || "";
                if (content) {
                  fullResponse += content;
                  controller.enqueue(new TextEncoder().encode(content));
                }
              }
            } else if (provider === "anthropic") {
              const anthropic = new Anthropic({ apiKey });
              const msgParams: Anthropic.MessageCreateParams = {
                model,
                max_tokens: maxTokens,
                temperature,
                messages: chatMessages
                  .filter((m) => m.role !== "system")
                  .map((m) => ({
                    role: m.role as "user" | "assistant",
                    content: m.content,
                  })),
              };

              const response = await anthropic.messages.create({
                ...msgParams,
                stream: true,
              });

              for await (const chunk of response) {
                if (chunk.type === "content_block_delta") {
                  const content = (chunk.delta as { text?: string }).text || "";
                  if (content) {
                    fullResponse += content;
                    controller.enqueue(new TextEncoder().encode(content));
                  }
                }
              }
            } else if (provider === "google") {
              const genAI = new GoogleGenerativeAI(apiKey);
              const genModel = genAI.getGenerativeModel({ model });

              const geminiHistory = chatMessages
                .filter((m) => m.role !== "system")
                .map((m) => ({
                  role: m.role === "user" ? "user" : "model",
                  parts: [{ text: m.content }],
                }));

              const chat = genModel.startChat({
                history: geminiHistory.slice(0, -1),
                generationConfig: {
                  temperature,
                  maxOutputTokens: maxTokens,
                },
              });

              const lastMessage = geminiHistory.at(-1);
              if (lastMessage) {
                const result = await chat.sendMessageStream(lastMessage.parts[0].text);
                for await (const chunk of result.stream) {
                  const content = chunk.text() || "";
                  if (content) {
                    fullResponse += content;
                    controller.enqueue(new TextEncoder().encode(content));
                  }
                }
              }
            }

            // Save assistant message
            await getDb().insert(messages).values({
              conversationId: input.conversationId,
              role: "assistant",
              content: fullResponse,
            });

            controller.close();
          } catch (error) {
            const errorMessage = error instanceof Error ? error.message : "Unknown error";
            controller.enqueue(
              new TextEncoder().encode(`\n\n[Error: ${errorMessage}]`),
            );
            controller.close();
          }
        },
      });

      return new Response(stream, {
        headers: {
          "Content-Type": "text/plain; charset=utf-8",
          "Cache-Control": "no-cache",
          Connection: "keep-alive",
        },
      });
    }),
});
