import { z } from "zod";
import { eq, and } from "drizzle-orm";
import { TRPCError } from "@trpc/server";
import { createRouter, authedQuery } from "./middleware";
import { getDb } from "./queries/connection";
import { apiKeys } from "@db/schema";
import CryptoJS from "crypto-js";
import { env } from "./lib/env";

const ENCRYPTION_KEY = env.appSecret;

function encryptKey(plainValue: string): string {
  return CryptoJS.AES.encrypt(plainValue, ENCRYPTION_KEY).toString();
}

function decryptKey(encryptedValue: string): string {
  const bytes = CryptoJS.AES.decrypt(encryptedValue, ENCRYPTION_KEY);
  return bytes.toString(CryptoJS.enc.Utf8);
}

export const apiKeyRouter = createRouter({
  list: authedQuery.query(async ({ ctx }) => {
    const user = ctx.unifiedUser;
    const rows = await getDb()
      .select({
        id: apiKeys.id,
        provider: apiKeys.provider,
        createdAt: apiKeys.createdAt,
      })
      .from(apiKeys)
      .where(
        and(
          eq(apiKeys.userId, user.id),
          eq(apiKeys.userType, user.authType),
        ),
      );

    return rows.map((r) => ({
      ...r,
      hasKey: true,
    }));
  }),

  getByProvider: authedQuery
    .input(z.object({ provider: z.enum(["openai", "anthropic", "google"]) }))
    .query(async ({ ctx, input }) => {
      const user = ctx.unifiedUser;
      const rows = await getDb()
        .select()
        .from(apiKeys)
        .where(
          and(
            eq(apiKeys.userId, user.id),
            eq(apiKeys.userType, user.authType),
            eq(apiKeys.provider, input.provider),
          ),
        )
        .limit(1);

      const record = rows.at(0);
      if (!record) return null;

      return {
        id: record.id,
        provider: record.provider,
        hasKey: true,
      };
    }),

  upsert: authedQuery
    .input(
      z.object({
        provider: z.enum(["openai", "anthropic", "google"]),
        keyValue: z.string().min(1),
      }),
    )
    .mutation(async ({ ctx, input }) => {
      const user = ctx.unifiedUser;

      const existing = await getDb()
        .select()
        .from(apiKeys)
        .where(
          and(
            eq(apiKeys.userId, user.id),
            eq(apiKeys.userType, user.authType),
            eq(apiKeys.provider, input.provider),
          ),
        )
        .limit(1);

      const encryptedKey = encryptKey(input.keyValue);

      if (existing.at(0)) {
        await getDb()
          .update(apiKeys)
          .set({ keyValue: encryptedKey })
          .where(eq(apiKeys.id, existing[0].id));
        return { id: existing[0].id, provider: input.provider };
      } else {
        const result = await getDb().insert(apiKeys).values({
          userId: user.id,
          userType: user.authType,
          provider: input.provider,
          keyValue: encryptedKey,
        });
        return { id: Number(result[0].insertId), provider: input.provider };
      }
    }),

  delete: authedQuery
    .input(z.object({ provider: z.enum(["openai", "anthropic", "google"]) }))
    .mutation(async ({ ctx, input }) => {
      const user = ctx.unifiedUser;
      await getDb()
        .delete(apiKeys)
        .where(
          and(
            eq(apiKeys.userId, user.id),
            eq(apiKeys.userType, user.authType),
            eq(apiKeys.provider, input.provider),
          ),
        );
      return { success: true };
    }),

  test: authedQuery
    .input(z.object({ provider: z.enum(["openai", "anthropic", "google"]) }))
    .mutation(async ({ ctx, input }) => {
      const user = ctx.unifiedUser;
      const rows = await getDb()
        .select()
        .from(apiKeys)
        .where(
          and(
            eq(apiKeys.userId, user.id),
            eq(apiKeys.userType, user.authType),
            eq(apiKeys.provider, input.provider),
          ),
        )
        .limit(1);

      const record = rows.at(0);
      if (!record) {
        throw new TRPCError({
          code: "BAD_REQUEST",
          message: "No API key found for this provider",
        });
      }

      try {
        const apiKey = decryptKey(record.keyValue);

        if (input.provider === "openai") {
          const { OpenAI } = await import("openai");
          const openai = new OpenAI({ apiKey });
          await openai.models.list();
        } else if (input.provider === "anthropic") {
          const Anthropic = (await import("@anthropic-ai/sdk")).default;
          const anthropic = new Anthropic({ apiKey });
          await anthropic.messages.create({
            model: "claude-3-haiku-20240307",
            max_tokens: 10,
            messages: [{ role: "user", content: "Hi" }],
          });
        } else if (input.provider === "google") {
          const { GoogleGenerativeAI } = await import("@google/generative-ai");
          const genAI = new GoogleGenerativeAI(apiKey);
          const model = genAI.getGenerativeModel({ model: "gemini-1.5-flash" });
          await model.generateContent("Hi");
        }

        return { success: true };
      } catch (error) {
        const message = error instanceof Error ? error.message : "Connection failed";
        throw new TRPCError({
          code: "BAD_REQUEST",
          message: `API key test failed: ${message}`,
        });
      }
    }),
});
