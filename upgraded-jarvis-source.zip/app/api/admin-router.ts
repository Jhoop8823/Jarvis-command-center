import { z } from "zod";
import { eq, count, like, or } from "drizzle-orm";
import { createRouter, adminQuery } from "./middleware";
import { getDb } from "./queries/connection";
import { users, localUsers, conversations, messages } from "@db/schema";

export const adminRouter = createRouter({
  getStats: adminQuery.query(async () => {
    const db = getDb();

    const [oauthCount] = await db.select({ count: count() }).from(users);
    const [localCount] = await db.select({ count: count() }).from(localUsers);
    const [convCount] = await db.select({ count: count() }).from(conversations);
    const [msgCount] = await db.select({ count: count() }).from(messages);

    const today = new Date();
    today.setHours(0, 0, 0, 0);

    return {
      totalUsers: oauthCount.count + localCount.count,
      totalOAuthUsers: oauthCount.count,
      totalLocalUsers: localCount.count,
      totalConversations: convCount.count,
      totalMessages: msgCount.count,
    };
  }),

  getUsers: adminQuery
    .input(
      z.object({
        page: z.number().min(1).default(1),
        limit: z.number().min(1).max(100).default(50),
        search: z.string().optional(),
      }),
    )
    .query(async ({ input }) => {
      const db = getDb();
      const offset = (input.page - 1) * input.limit;

      // Get OAuth users
      const oauthUsers = await db
        .select({
          id: users.id,
          name: users.name,
          email: users.email,
          role: users.role,
          createdAt: users.createdAt,
        })
        .from(users)
        .where(
          input.search
            ? or(
                like(users.name || "", `%${input.search}%`),
                like(users.email || "", `%${input.search}%`),
              )
            : undefined,
        )
        .limit(input.limit)
        .offset(offset);

      // Get local users
      const localUsersList = await db
        .select({
          id: localUsers.id,
          name: localUsers.displayName,
          email: localUsers.email,
          role: localUsers.role,
          createdAt: localUsers.createdAt,
        })
        .from(localUsers)
        .where(
          input.search
            ? or(
                like(localUsers.displayName || "", `%${input.search}%`),
                like(localUsers.email || "", `%${input.search}%`),
                like(localUsers.username, `%${input.search}%`),
              )
            : undefined,
        )
        .limit(input.limit)
        .offset(offset);

      // Combine and add userType
      const combinedUsers = [
        ...oauthUsers.map((u) => ({ ...u, userType: "oauth" as const })),
        ...localUsersList.map((u) => ({ ...u, userType: "local" as const })),
      ];

      const [oauthTotal] = await db.select({ count: count() }).from(users);
      const [localTotal] = await db.select({ count: count() }).from(localUsers);

      return {
        users: combinedUsers,
        total: oauthTotal.count + localTotal.count,
      };
    }),

  updateUserRole: adminQuery
    .input(
      z.object({
        id: z.number(),
        userType: z.enum(["oauth", "local"]),
        role: z.enum(["user", "admin"]),
      }),
    )
    .mutation(async ({ input }) => {
      if (input.userType === "oauth") {
        await getDb()
          .update(users)
          .set({ role: input.role })
          .where(eq(users.id, input.id));
      } else {
        await getDb()
          .update(localUsers)
          .set({ role: input.role })
          .where(eq(localUsers.id, input.id));
      }
      return { success: true };
    }),
});
