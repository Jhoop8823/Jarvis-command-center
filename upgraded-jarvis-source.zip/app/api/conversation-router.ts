import { z } from "zod";
import { eq, and, desc } from "drizzle-orm";
import { TRPCError } from "@trpc/server";
import { createRouter, authedQuery } from "./middleware";
import { getDb } from "./queries/connection";
import { conversations, messages } from "@db/schema";

export const conversationRouter = createRouter({
  list: authedQuery.query(async ({ ctx }) => {
    const user = ctx.unifiedUser;
    return getDb()
      .select()
      .from(conversations)
      .where(
        and(
          eq(conversations.userId, user.id),
          eq(conversations.userType, user.authType),
        ),
      )
      .orderBy(desc(conversations.updatedAt));
  }),

  getById: authedQuery
    .input(z.object({ id: z.number() }))
    .query(async ({ ctx, input }) => {
      const user = ctx.unifiedUser;
      const convRows = await getDb()
        .select()
        .from(conversations)
        .where(
          and(
            eq(conversations.id, input.id),
            eq(conversations.userId, user.id),
            eq(conversations.userType, user.authType),
          ),
        )
        .limit(1);

      const conv = convRows.at(0);
      if (!conv) {
        throw new TRPCError({ code: "NOT_FOUND", message: "Conversation not found" });
      }

      const msgRows = await getDb()
        .select()
        .from(messages)
        .where(eq(messages.conversationId, input.id))
        .orderBy(messages.createdAt);

      return { ...conv, messages: msgRows };
    }),

  create: authedQuery
    .input(
      z.object({
        title: z.string().optional(),
        model: z.string().optional(),
        systemPromptId: z.number().optional(),
        temperature: z.number().optional(),
        maxTokens: z.number().optional(),
      }),
    )
    .mutation(async ({ ctx, input }) => {
      const user = ctx.unifiedUser;
      const result = await getDb().insert(conversations).values({
        userId: user.id,
        userType: user.authType,
        title: input.title || "New Conversation",
        model: input.model || "gpt-4o",
        systemPromptId: input.systemPromptId || null,
        temperature: input.temperature?.toString() || "0.70",
        maxTokens: input.maxTokens || 2048,
      });
      const id = Number(result[0].insertId);
      const rows = await getDb()
        .select()
        .from(conversations)
        .where(eq(conversations.id, id))
        .limit(1);
      return rows.at(0)!;
    }),

  update: authedQuery
    .input(
      z.object({
        id: z.number(),
        title: z.string().optional(),
        model: z.string().optional(),
        systemPromptId: z.number().nullable().optional(),
        temperature: z.number().optional(),
        maxTokens: z.number().optional(),
      }),
    )
    .mutation(async ({ ctx, input }) => {
      const user = ctx.unifiedUser;
      const existing = await getDb()
        .select()
        .from(conversations)
        .where(
          and(
            eq(conversations.id, input.id),
            eq(conversations.userId, user.id),
            eq(conversations.userType, user.authType),
          ),
        )
        .limit(1);

      if (!existing.at(0)) {
        throw new TRPCError({ code: "NOT_FOUND", message: "Conversation not found" });
      }

      const updateData: Record<string, unknown> = {};
      if (input.title !== undefined) updateData.title = input.title;
      if (input.model !== undefined) updateData.model = input.model;
      if (input.systemPromptId !== undefined) updateData.systemPromptId = input.systemPromptId;
      if (input.temperature !== undefined) updateData.temperature = input.temperature.toString();
      if (input.maxTokens !== undefined) updateData.maxTokens = input.maxTokens;

      await getDb()
        .update(conversations)
        .set(updateData)
        .where(eq(conversations.id, input.id));

      const rows = await getDb()
        .select()
        .from(conversations)
        .where(eq(conversations.id, input.id))
        .limit(1);
      return rows.at(0)!;
    }),

  delete: authedQuery
    .input(z.object({ id: z.number() }))
    .mutation(async ({ ctx, input }) => {
      const user = ctx.unifiedUser;
      const existing = await getDb()
        .select()
        .from(conversations)
        .where(
          and(
            eq(conversations.id, input.id),
            eq(conversations.userId, user.id),
            eq(conversations.userType, user.authType),
          ),
        )
        .limit(1);

      if (!existing.at(0)) {
        throw new TRPCError({ code: "NOT_FOUND", message: "Conversation not found" });
      }

      await getDb().delete(messages).where(eq(messages.conversationId, input.id));
      await getDb().delete(conversations).where(eq(conversations.id, input.id));

      return { success: true };
    }),
});
