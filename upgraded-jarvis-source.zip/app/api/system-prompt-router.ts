import { z } from "zod";
import { eq, and } from "drizzle-orm";
import { TRPCError } from "@trpc/server";
import { createRouter, authedQuery } from "./middleware";
import { getDb } from "./queries/connection";
import { systemPrompts } from "@db/schema";

export const systemPromptRouter = createRouter({
  list: authedQuery.query(async ({ ctx }) => {
    const user = ctx.unifiedUser;
    return getDb()
      .select()
      .from(systemPrompts)
      .where(
        and(
          eq(systemPrompts.userId, user.id),
          eq(systemPrompts.userType, user.authType),
        ),
      )
      .orderBy(systemPrompts.createdAt);
  }),

  getById: authedQuery
    .input(z.object({ id: z.number() }))
    .query(async ({ ctx, input }) => {
      const user = ctx.unifiedUser;
      const rows = await getDb()
        .select()
        .from(systemPrompts)
        .where(
          and(
            eq(systemPrompts.id, input.id),
            eq(systemPrompts.userId, user.id),
            eq(systemPrompts.userType, user.authType),
          ),
        )
        .limit(1);

      const prompt = rows.at(0);
      if (!prompt) {
        throw new TRPCError({ code: "NOT_FOUND", message: "System prompt not found" });
      }
      return prompt;
    }),

  create: authedQuery
    .input(
      z.object({
        name: z.string().min(1),
        content: z.string().min(1),
        isDefault: z.boolean().optional(),
      }),
    )
    .mutation(async ({ ctx, input }) => {
      const user = ctx.unifiedUser;

      if (input.isDefault) {
        await getDb()
          .update(systemPrompts)
          .set({ isDefault: false })
          .where(
            and(
              eq(systemPrompts.userId, user.id),
              eq(systemPrompts.userType, user.authType),
            ),
          );
      }

      const result = await getDb().insert(systemPrompts).values({
        userId: user.id,
        userType: user.authType,
        name: input.name,
        content: input.content,
        isDefault: input.isDefault || false,
      });

      const id = Number(result[0].insertId);
      const rows = await getDb()
        .select()
        .from(systemPrompts)
        .where(eq(systemPrompts.id, id))
        .limit(1);
      return rows.at(0)!;
    }),

  update: authedQuery
    .input(
      z.object({
        id: z.number(),
        name: z.string().optional(),
        content: z.string().optional(),
        isDefault: z.boolean().optional(),
      }),
    )
    .mutation(async ({ ctx, input }) => {
      const user = ctx.unifiedUser;
      const existing = await getDb()
        .select()
        .from(systemPrompts)
        .where(
          and(
            eq(systemPrompts.id, input.id),
            eq(systemPrompts.userId, user.id),
            eq(systemPrompts.userType, user.authType),
          ),
        )
        .limit(1);

      if (!existing.at(0)) {
        throw new TRPCError({ code: "NOT_FOUND", message: "System prompt not found" });
      }

      if (input.isDefault) {
        await getDb()
          .update(systemPrompts)
          .set({ isDefault: false })
          .where(
            and(
              eq(systemPrompts.userId, user.id),
              eq(systemPrompts.userType, user.authType),
            ),
          );
      }

      const updateData: Record<string, unknown> = {};
      if (input.name !== undefined) updateData.name = input.name;
      if (input.content !== undefined) updateData.content = input.content;
      if (input.isDefault !== undefined) updateData.isDefault = input.isDefault;

      await getDb()
        .update(systemPrompts)
        .set(updateData)
        .where(eq(systemPrompts.id, input.id));

      const rows = await getDb()
        .select()
        .from(systemPrompts)
        .where(eq(systemPrompts.id, input.id))
        .limit(1);
      return rows.at(0)!;
    }),

  delete: authedQuery
    .input(z.object({ id: z.number() }))
    .mutation(async ({ ctx, input }) => {
      const user = ctx.unifiedUser;
      const existing = await getDb()
        .select()
        .from(systemPrompts)
        .where(
          and(
            eq(systemPrompts.id, input.id),
            eq(systemPrompts.userId, user.id),
            eq(systemPrompts.userType, user.authType),
          ),
        )
        .limit(1);

      if (!existing.at(0)) {
        throw new TRPCError({ code: "NOT_FOUND", message: "System prompt not found" });
      }

      await getDb().delete(systemPrompts).where(eq(systemPrompts.id, input.id));
      return { success: true };
    }),
});
