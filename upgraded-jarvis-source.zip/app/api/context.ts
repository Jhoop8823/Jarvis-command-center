import type { FetchCreateContextFnOptions } from "@trpc/server/adapters/fetch";
import type { User } from "@db/schema";
import type { UnifiedUser } from "@contracts/types";
import { authenticateRequest } from "./kimi/auth";
import { verifyLocalToken } from "./local-auth-utils";

export type TrpcContext = {
  req: Request;
  resHeaders: Headers;
  user?: User;
  unifiedUser?: UnifiedUser;
};

export async function createContext(
  opts: FetchCreateContextFnOptions,
): Promise<TrpcContext> {
  const ctx: TrpcContext = { req: opts.req, resHeaders: opts.resHeaders };

  // Try OAuth first
  try {
    const user = await authenticateRequest(opts.req.headers);
    if (user) {
      ctx.user = user;
      ctx.unifiedUser = {
        id: user.id,
        name: user.name || "User",
        email: user.email,
        avatar: user.avatar,
        role: user.role as "user" | "admin",
        authType: "oauth",
      };
      return ctx;
    }
  } catch {
    // OAuth auth failed, try local auth
  }

  // Try local auth via x-local-auth-token header
  try {
    const localToken = opts.req.headers.get("x-local-auth-token");
    if (localToken) {
      const localUser = await verifyLocalToken(localToken);
      if (localUser) {
        ctx.unifiedUser = {
          id: localUser.id,
          name: localUser.displayName || localUser.username,
          email: localUser.email,
          avatar: null,
          role: localUser.role as "user" | "admin",
          authType: "local",
        };
      }
    }
  } catch {
    // Local auth failed
  }

  return ctx;
}
