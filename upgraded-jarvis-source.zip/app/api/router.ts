import { authRouter } from "./auth-router";
import { localAuthRouter } from "./local-auth-router";
import { conversationRouter } from "./conversation-router";
import { messageRouter } from "./message-router";
import { chatRouter } from "./chat-router";
import { systemPromptRouter } from "./system-prompt-router";
import { apiKeyRouter } from "./api-key-router";
import { adminRouter } from "./admin-router";
import { createRouter, publicQuery } from "./middleware";

export const appRouter = createRouter({
  ping: publicQuery.query(() => ({ ok: true, ts: Date.now() })),
  auth: authRouter,
  localAuth: localAuthRouter,
  conversation: conversationRouter,
  message: messageRouter,
  chat: chatRouter,
  systemPrompt: systemPromptRouter,
  apiKey: apiKeyRouter,
  admin: adminRouter,
});

export type AppRouter = typeof appRouter;
