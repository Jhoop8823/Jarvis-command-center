import { z } from "zod";
import { eq } from "drizzle-orm";
import { createRouter, authedQuery } from "./middleware";
import { getDb } from "./queries/connection";
import { messages } from "@db/schema";

export const messageRouter = createRouter({
  create: authedQuery
    .input(
      z.object({
        conversationId: z.number(),
        role: z.enum(["user", "assistant", "system"]),
        content: z.string(),
      }),
    )
    .mutation(async ({ input }) => {
      const result = await getDb().insert(messages).values({
        conversationId: input.conversationId,
        role: input.role,
        content: input.content,
      });
      const id = Number(result[0].insertId);
      const rows = await getDb()
        .select()
        .from(messages)
        .where(eq(messages.id, id))
        .limit(1);
      return rows.at(0)!;
    }),

  listByConversation: authedQuery
    .input(z.object({ conversationId: z.number() }))
    .query(async ({ input }) => {
      return getDb()
        .select()
        .from(messages)
        .where(eq(messages.conversationId, input.conversationId))
        .orderBy(messages.createdAt);
    }),
});
