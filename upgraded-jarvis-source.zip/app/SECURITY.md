# Security Notes

This project handles user credentials and third-party API keys. Treat it as a security-sensitive application.

## Rules

1. Never expose stored API keys back to the browser.
2. Never commit `.env` files.
3. Use a strong production `APP_SECRET`.
4. Rotate secrets if a deployment environment is compromised.
5. Keep provider calls server-side.
6. Add rate limiting before public deployment.
7. Add audit logs before adding destructive automation features.

## API Key Handling

The safer pattern is:

- Browser submits a key once.
- Backend encrypts it.
- Database stores only the encrypted value.
- Frontend receives only metadata such as provider and configured status.
- Backend decrypts only when testing or calling the provider.

## Before Public Launch

- run `npm audit`
- verify all protected routes require authentication
- verify admin-only routes check admin permissions server-side
- add request throttling
- add error sanitization so provider failures do not leak secrets
