export type UnifiedUser = {
  id: number;
  name: string;
  email?: string | null;
  avatar?: string | null;
  role: "user" | "admin";
  authType: "oauth" | "local";
};

export type AIProvider = "openai" | "anthropic" | "google";

export type AIModel =
  | "gpt-4o"
  | "gpt-4o-mini"
  | "claude-3-5-sonnet-20241022"
  | "claude-3-7-sonnet-20250219"
  | "gemini-1.5-pro-latest";

export const MODEL_PROVIDER_MAP: Record<AIModel, AIProvider> = {
  "gpt-4o": "openai",
  "gpt-4o-mini": "openai",
  "claude-3-5-sonnet-20241022": "anthropic",
  "claude-3-7-sonnet-20250219": "anthropic",
  "gemini-1.5-pro-latest": "google",
};

export const DEFAULT_SYSTEM_PROMPT = "You are J.A.R.V.I.S., a highly advanced AI assistant. You are helpful, precise, and communicate with clarity. You have a sophisticated personality befitting an AI command center. Respond concisely but thoroughly.";
