import { useState } from "react";
import { motion } from "framer-motion";
import {
  Key,
  Eye,
  EyeOff,
  Save,
  Trash2,
  CheckCircle2,
  XCircle,
  Loader2,
  ExternalLink,
} from "lucide-react";
import { trpc } from "@/providers/trpc";

const PROVIDERS = [
  {
    id: "openai" as const,
    name: "OpenAI",
    description: "GPT-4o, GPT-4o Mini",
    url: "https://platform.openai.com/api-keys",
    color: "from-emerald-500/10 to-emerald-500/5",
    borderColor: "border-emerald-500/20",
    iconColor: "text-emerald-400/60",
  },
  {
    id: "anthropic" as const,
    name: "Anthropic",
    description: "Claude 3.5 Sonnet, Claude 3.7 Sonnet",
    url: "https://console.anthropic.com/settings/keys",
    color: "from-amber-500/10 to-amber-500/5",
    borderColor: "border-amber-500/20",
    iconColor: "text-amber-400/60",
  },
  {
    id: "google" as const,
    name: "Google",
    description: "Gemini 1.5 Pro",
    url: "https://aistudio.google.com/app/apikey",
    color: "from-blue-500/10 to-blue-500/5",
    borderColor: "border-blue-500/20",
    iconColor: "text-blue-400/60",
  },
];

export default function ApiKeys() {
  const utils = trpc.useUtils();
  const [visibleKeys, setVisibleKeys] = useState<Record<string, boolean>>({});
  const [inputValues, setInputValues] = useState<Record<string, string>>({});
  const [testingProvider, setTestingProvider] = useState<string | null>(null);

  const { data: apiKeysList } = trpc.apiKey.list.useQuery();
  const { data: openaiKey } = trpc.apiKey.getByProvider.useQuery(
    { provider: "openai" },
    { enabled: apiKeysList?.some((k) => k.provider === "openai") },
  );
  const { data: anthropicKey } = trpc.apiKey.getByProvider.useQuery(
    { provider: "anthropic" },
    { enabled: apiKeysList?.some((k) => k.provider === "anthropic") },
  );
  const { data: googleKey } = trpc.apiKey.getByProvider.useQuery(
    { provider: "google" },
    { enabled: apiKeysList?.some((k) => k.provider === "google") },
  );

  const upsertKey = trpc.apiKey.upsert.useMutation({
    onSuccess: () => {
      utils.apiKey.list.invalidate();
      utils.apiKey.getByProvider.invalidate();
    },
  });

  const deleteKey = trpc.apiKey.delete.useMutation({
    onSuccess: () => {
      utils.apiKey.list.invalidate();
      utils.apiKey.getByProvider.invalidate();
    },
  });

  const testKey = trpc.apiKey.test.useMutation();

  const getStoredKey = (provider: string) => {
    switch (provider) {
      case "openai":
        return openaiKey?.keyValue || "";
      case "anthropic":
        return anthropicKey?.keyValue || "";
      case "google":
        return googleKey?.keyValue || "";
      default:
        return "";
    }
  };

  const hasKey = (provider: string) => {
    return apiKeysList?.some((k) => k.provider === provider);
  };

  const toggleVisibility = (provider: string) => {
    setVisibleKeys((prev) => ({ ...prev, [provider]: !prev[provider] }));
  };

  const handleSave = (providerId: "openai" | "anthropic" | "google") => {
    const value = inputValues[providerId];
    if (!value?.trim()) return;
    upsertKey.mutate({ provider: providerId, keyValue: value.trim() });
  };

  const handleDelete = (providerId: "openai" | "anthropic" | "google") => {
    if (confirm("Remove this API key?")) {
      deleteKey.mutate({ provider: providerId });
      setInputValues((prev) => ({ ...prev, [providerId]: "" }));
    }
  };

  const handleTest = async (providerId: "openai" | "anthropic" | "google") => {
    setTestingProvider(providerId);
    try {
      await testKey.mutateAsync({ provider: providerId });
      alert("API key is valid and working!");
    } catch (err) {
      const msg = err instanceof Error ? err.message : "Test failed";
      alert(`Test failed: ${msg}`);
    }
    setTestingProvider(null);
  };

  return (
    <div className="h-full glass-panel rounded-xl overflow-hidden flex flex-col">
      {/* Header */}
      <div className="h-14 border-b border-cyan-500/10 flex items-center px-6">
        <Key className="w-5 h-5 text-cyan-400/60 mr-3" />
        <h1 className="text-lg font-semibold text-cyan-200">API Keys</h1>
        <span className="ml-auto telemetry-text">ENCRYPTED STORAGE</span>
      </div>

      {/* Content */}
      <div className="flex-1 overflow-auto p-4">
        <div className="grid gap-4 max-w-2xl mx-auto">
          {PROVIDERS.map((provider, index) => (
            <motion.div
              key={provider.id}
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: index * 0.1 }}
              className={`glass-panel rounded-xl p-5 border ${provider.borderColor} bg-gradient-to-br ${provider.color}`}
            >
              <div className="flex items-start justify-between mb-4">
                <div>
                  <h3 className="text-sm font-semibold text-cyan-200">{provider.name}</h3>
                  <p className="text-[11px] text-cyan-100/30 mt-0.5">{provider.description}</p>
                </div>
                <div className="flex items-center gap-2">
                  {hasKey(provider.id) ? (
                    <span className="flex items-center gap-1 px-2 py-0.5 rounded-full bg-emerald-500/10 border border-emerald-500/20 text-[9px] text-emerald-400/70 font-mono-telemetry">
                      <CheckCircle2 className="w-2.5 h-2.5" />
                      CONFIGURED
                    </span>
                  ) : (
                    <span className="flex items-center gap-1 px-2 py-0.5 rounded-full bg-cyan-500/5 border border-cyan-500/10 text-[9px] text-cyan-400/30 font-mono-telemetry">
                      <XCircle className="w-2.5 h-2.5" />
                      NOT SET
                    </span>
                  )}
                </div>
              </div>

              {/* Key Input */}
              <div className="relative mb-3">
                <input
                  type={visibleKeys[provider.id] ? "text" : "password"}
                  value={
                    inputValues[provider.id] !== undefined
                      ? inputValues[provider.id]
                      : getStoredKey(provider.id)
                  }
                  onChange={(e) =>
                    setInputValues((prev) => ({ ...prev, [provider.id]: e.target.value }))
                  }
                  placeholder={`Enter your ${provider.name} API key`}
                  className="w-full glass-input pl-3 pr-20 py-2.5 rounded-lg text-xs"
                />
                <button
                  onClick={() => toggleVisibility(provider.id)}
                  className="absolute right-10 top-1/2 -translate-y-1/2 p-1.5 text-cyan-400/30 hover:text-cyan-300 transition-colors"
                >
                  {visibleKeys[provider.id] ? (
                    <EyeOff className="w-3.5 h-3.5" />
                  ) : (
                    <Eye className="w-3.5 h-3.5" />
                  )}
                </button>
                <a
                  href={provider.url}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="absolute right-2 top-1/2 -translate-y-1/2 p-1.5 text-cyan-400/20 hover:text-cyan-300 transition-colors"
                >
                  <ExternalLink className="w-3.5 h-3.5" />
                </a>
              </div>

              {/* Actions */}
              <div className="flex items-center gap-2">
                <button
                  onClick={() => handleSave(provider.id)}
                  disabled={
                    !inputValues[provider.id]?.trim() ||
                    upsertKey.isPending
                  }
                  className="glass-button-primary px-3 py-1.5 rounded-lg text-xs flex items-center gap-1.5 disabled:opacity-30"
                >
                  {upsertKey.isPending ? (
                    <Loader2 className="w-3 h-3 animate-spin" />
                  ) : (
                    <Save className="w-3 h-3" />
                  )}
                  Save
                </button>

                {hasKey(provider.id) && (
                  <>
                    <button
                      onClick={() => handleTest(provider.id)}
                      disabled={testingProvider === provider.id}
                      className="glass-button px-3 py-1.5 rounded-lg text-xs flex items-center gap-1.5 disabled:opacity-30"
                    >
                      {testingProvider === provider.id ? (
                        <Loader2 className="w-3 h-3 animate-spin" />
                      ) : (
                        <CheckCircle2 className="w-3 h-3" />
                      )}
                      Test
                    </button>
                    <button
                      onClick={() => handleDelete(provider.id)}
                      className="px-3 py-1.5 rounded-lg text-xs flex items-center gap-1.5 text-red-400/50 hover:text-red-400 hover:bg-red-500/10 transition-all"
                    >
                      <Trash2 className="w-3 h-3" />
                      Remove
                    </button>
                  </>
                )}
              </div>
            </motion.div>
          ))}
        </div>

        {/* Info */}
        <div className="mt-6 max-w-2xl mx-auto p-4 rounded-xl bg-cyan-500/5 border border-cyan-500/10">
          <p className="text-[11px] text-cyan-200/40 leading-relaxed">
            <span className="text-cyan-400/60 font-medium">Security Note:</span> Your API keys are encrypted using AES-256-GCM before storage. 
            They are never exposed in the frontend except when you explicitly view them. 
            Keys are only decrypted when making API calls to the respective AI providers.
          </p>
        </div>
      </div>
    </div>
  );
}
